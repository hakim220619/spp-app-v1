"use strict";
(() => {
var exports = {};
exports.id = 880;
exports.ids = [880];
exports.modules = {

/***/ 963:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 3168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(963);
/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mysql2_promise__WEBPACK_IMPORTED_MODULE_0__);

const { DB_HOST , DB_NAME , DB_USER , DB_PASSWORD  } = process.env;
// Function to create connection to MySQL database
async function createConnection() {
    return await mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default().createConnection({
        host: DB_HOST,
        user: DB_USER,
        password: DB_PASSWORD,
        database: DB_NAME
    });
}
async function handler(req, res) {
    try {
        const connection = await createConnection();
        console.log(req.query.school_id);
        // Misalnya mengambil client-key dari tabel aplikasi
        const [rows] = await connection.execute("SELECT * FROM aplikasi WHERE school_id = ?", [
            req.query.school_id
        ]);
        if (rows.length === 0) {
            return res.status(404).json({
                message: "Client key not found"
            });
        }
        const data = rows[0];
        res.status(200).json({
            data
        });
    } catch (error) {
        res.status(500).json({
            error: error.message
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3168));
module.exports = __webpack_exports__;

})();