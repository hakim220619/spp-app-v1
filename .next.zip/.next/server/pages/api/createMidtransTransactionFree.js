"use strict";
(() => {
var exports = {};
exports.id = 6593;
exports.ids = [6593];
exports.modules = {

/***/ 8712:
/***/ ((module) => {

module.exports = require("midtrans-client");

/***/ }),

/***/ 963:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 6285:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var midtrans_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8712);
/* harmony import */ var midtrans_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(midtrans_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(963);
/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mysql2_promise__WEBPACK_IMPORTED_MODULE_1__);
// @ts-ignore: midtrans-client has no type definitions


const { DB_HOST , DB_NAME , DB_USER , DB_PASSWORD  } = process.env;
// Function to create connection to MySQL database
async function createConnection() {
    return await mysql2_promise__WEBPACK_IMPORTED_MODULE_1___default().createConnection({
        host: DB_HOST,
        user: DB_USER,
        password: DB_PASSWORD,
        database: DB_NAME
    });
}
async function handler(req, res) {
    if (req.method !== "POST") {
        return res.status(405).json({
            message: "Method not allowed"
        });
    }
    const { total_amount , dataPayment , school_id  } = req.body;
    if (!school_id) {
        return res.status(400).json({
            message: "School ID is required"
        });
    }
    try {
        // Create connection to MySQL database
        const connection = await createConnection();
        // Query to get the Midtrans configuration from the database based on school_id
        const [rows] = await connection.execute("SELECT serverKey, is_production FROM aplikasi WHERE school_id = ?", [
            school_id
        ]);
        if (rows.length === 0) {
            return res.status(404).json({
                message: "Configuration not found for the given school ID"
            });
        }
        const midtransConfig = rows[0];
        // Initialize Snap with the values from the database
        const snap = new (midtrans_client__WEBPACK_IMPORTED_MODULE_0___default().Snap)({
            isProduction: midtransConfig.is_production === "true",
            serverKey: midtransConfig.serverKey // Use server key from DB
        });
        const orderId = "SPP-" + Math.floor(100000 + Math.random() * 900000);
        const itemDetails = [
            {
                id: `ITEM-${dataPayment.id}`,
                price: total_amount,
                quantity: 1,
                name: dataPayment.sp_name // Nama item sesuai dengan bulan dan tahun pembayaran
            }
        ];
        const transactionDetails = {
            transaction_details: {
                order_id: orderId,
                gross_amount: total_amount // Total pembayaran
            },
            customer_details: {
                first_name: dataPayment.full_name,
                email: dataPayment.email,
                phone: dataPayment.phone
            },
            item_details: itemDetails
        };
        try {
            const transaction = await snap.createTransaction(transactionDetails);
            res.status(200).json({
                transactionToken: transaction.token,
                transactionUrl: transaction.redirect_url,
                orderId: orderId
            });
        } catch (error) {
            console.error("Midtrans error:", error);
            res.status(500).json({
                error: error.message
            });
        }
    } catch (error) {
        console.error("Database or Midtrans error:", error);
        res.status(500).json({
            error: error.message
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6285));
module.exports = __webpack_exports__;

})();