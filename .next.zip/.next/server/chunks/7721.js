"use strict";
exports.id = 7721;
exports.ids = [7721];
exports.modules = {

/***/ 7721:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var src_core_components_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3730);
/* harmony import */ var src_core_hooks_useBgColor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(591);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_core_components_icon__WEBPACK_IMPORTED_MODULE_3__]);
src_core_components_icon__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// ** MUI Imports



// ** Custom Icon Import

// ** Hooks Imports

// Styled Box component
const Box = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.styled)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()))(()=>({
        width: 20,
        height: 20,
        borderWidth: 3,
        borderRadius: "50%",
        borderStyle: "solid"
    }));
const StepperCustomDot = (props)=>{
    // ** Props
    const { active , completed , error  } = props;
    // ** Hooks
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    const bgColors = (0,src_core_hooks_useBgColor__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    if (error) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_icon__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            icon: "tabler:alert-triangle",
            fontSize: 20,
            color: theme.palette.error.main,
            transform: "scale(1.2)"
        });
    } else if (completed) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_icon__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            icon: "tabler:circle-check",
            fontSize: 20,
            color: theme.palette.primary.main,
            transform: "scale(1.2)"
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Box, {
            sx: {
                borderColor: bgColors.primaryLight.backgroundColor,
                ...active && {
                    borderWidth: 5,
                    borderColor: "primary.main",
                    backgroundColor: theme.palette.mode === "light" ? "common.white" : "background.default"
                }
            }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StepperCustomDot);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;