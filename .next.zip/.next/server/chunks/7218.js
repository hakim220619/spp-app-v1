"use strict";
exports.id = 7218;
exports.ids = [7218];
exports.modules = {

/***/ 8582:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    meEndpoint: "/cheklogin",
    loginEndpoint: "/jwt/login",
    registerEndpoint: "/jwt/register",
    storageTokenKeyName: "token",
    onTokenExpiration: "refreshToken" // logout | refreshToken
});


/***/ }),

/***/ 2089:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ AuthProvider),
/* harmony export */   "V": () => (/* binding */ AuthContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9915);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var src_configs_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8582);
/* harmony import */ var src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7740);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_2__, src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_5__]);
([js_cookie__WEBPACK_IMPORTED_MODULE_2__, src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// ** React Imports


 // Import js-cookie
// ** Next Import

// ** Config


// ** Defaults
const defaultProvider = {
    user: null,
    loading: true,
    setUser: ()=>null,
    setLoading: ()=>Boolean,
    login: ()=>Promise.resolve(),
    logout: ()=>Promise.resolve()
};
const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(defaultProvider);
const AuthProvider = ({ children  })=>{
    // ** States
    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(defaultProvider.user);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(defaultProvider.loading);
    // ** Hooks
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (router.pathname == "/ppdb") {
            router.push("/ppdb");
            setLoading(false);
        } else if (router.pathname == "/ppdb/login") {
            router.push("/ppdb/login");
            setLoading(false);
        } else if (router.pathname == "/ppdb/dahsboard") {
            router.push("/ppdb/dahsboard");
            setLoading(false);
            return;
        } else {
            const initAuth = async ()=>{
                const storedToken = window.localStorage.getItem("token");
                if (storedToken) {
                    setLoading(true);
                    await checkLogin(storedToken);
                } else {
                    setLoading(false);
                    router.replace("/login");
                }
            };
            const checkLogin = async (token)=>{
                setLoading(true);
                try {
                    const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_5__/* ["default"].get */ .Z.get("/checklogin", {
                        headers: {
                            Accept: "application/json",
                            Authorization: "Bearer " + token
                        }
                    });
                    setLoading(false);
                    setUser({
                        ...response.data.userData
                    });
                } catch (error) {
                    handleAuthError(error);
                } finally{
                    setLoading(false);
                }
            };
            const handleAuthError = async (error)=>{
                localStorage.removeItem("userData");
                setUser(null);
                if (error.response) {
                    const errorMessage = error.response.data.message;
                    if (errorMessage === "Invalid token") {
                        // Attempt to refresh token if "Invalid token"
                        await refreshAccessToken();
                    } else {
                        // Handle other errors
                        if (src_configs_auth__WEBPACK_IMPORTED_MODULE_4__/* ["default"].onTokenExpiration */ .Z.onTokenExpiration === "logout" && !router.pathname.includes("login")) {
                            router.replace("/login");
                        }
                    }
                } else {
                    console.error("Authentication error:", error) // Log unknown errors
                    ;
                    router.replace("/login") // Redirect to login for other errors
                    ;
                }
            };
            const refreshAccessToken = async ()=>{
                const refreshToken = localStorage.getItem("refreshToken");
                if (!refreshToken) {
                    router.replace("/login");
                    return;
                }
                try {
                    const storedToken = localStorage.getItem("token");
                    const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_5__/* ["default"].get */ .Z.get("/refresh-token", {
                        headers: {
                            Accept: "application/json",
                            Authorization: `Bearer ${storedToken}`
                        }
                    });
                    const newAccessToken = response.data.accessToken;
                    const userData = response.data.userData;
                    // Update local storage
                    window.localStorage.setItem("token", newAccessToken);
                    window.localStorage.setItem("userData", JSON.stringify(userData));
                    // Set cookies for token and userData
                    js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].set("token", newAccessToken, {
                        expires: 7
                    }) // Set cookie for 7 days
                    ;
                    js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].set("userData", JSON.stringify(userData), {
                        expires: 7
                    }) // Set cookie for 7 days
                    ;
                    setUser({
                        ...userData
                    });
                } catch (error) {
                    console.error("Failed to refresh token:", error) // Log refresh token errors
                    ;
                    handleLogout();
                }
            };
            initAuth();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const handleLogin = (params, errorCallback)=>{
        src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_5__/* ["default"].post */ .Z.post("/login", params).then(async (response)=>{
            if (params.rememberMe) {
                window.localStorage.setItem("token", response.data.accessToken);
                window.localStorage.setItem("refreshToken", response.data.refreshToken) // Ensure to store refresh token
                ;
                window.localStorage.setItem("userData", JSON.stringify(response.data.userData));
                // Set cookies for token and userData
                js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].set("token", response.data.accessToken, {
                    expires: 7
                }) // Set cookie for 7 days
                ;
                js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].set("userData", JSON.stringify(response.data.userData), {
                    expires: 7
                }) // Set cookie for 7 days
                ;
            }
            const returnUrl = router.query.returnUrl;
            setUser({
                ...response.data.userData
            });
            const redirectURL = returnUrl && returnUrl !== "/" ? returnUrl : "/";
            router.replace(redirectURL);
        }).catch((err)=>{
            if (errorCallback) errorCallback(err);
        });
    };
    const handleLogout = ()=>{
        setUser(null);
        window.localStorage.removeItem("userData");
        window.localStorage.removeItem("token");
        window.localStorage.removeItem("refreshToken");
        // Remove cookies
        js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].remove("token");
        js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].remove("userData");
        router.push("/login");
    };
    const values = {
        user,
        loading,
        setUser,
        setLoading,
        login: handleLogin,
        logout: handleLogout
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthContext.Provider, {
        value: values,
        children: children
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7218:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useAuth)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_context_AuthContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2089);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_context_AuthContext__WEBPACK_IMPORTED_MODULE_1__]);
src_context_AuthContext__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const useAuth = ()=>(0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(src_context_AuthContext__WEBPACK_IMPORTED_MODULE_1__/* .AuthContext */ .V);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;