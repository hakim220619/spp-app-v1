"use strict";
exports.id = 1970;
exports.ids = [1970];
exports.modules = {

/***/ 7740:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const axiosConfig = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    // baseURL: `http://localhost:3000/api`
    baseURL: `https://express-spp-api.sppapp.com/api`
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosConfig);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6272:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// const urlImage = `http://localhost:3000/`
const urlImage = `https://express-spp-api.sppapp.com/`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (urlImage);


/***/ }),

/***/ 1970:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8167);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Card__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9271);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9361);
/* harmony import */ var _mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8455);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_CardActions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3691);
/* harmony import */ var _mui_material_CardActions__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardActions__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6456);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7740);
/* harmony import */ var _mui_x_data_grid__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7738);
/* harmony import */ var _mui_x_data_grid__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var src_configs_url_image__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_14__]);
src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_14__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

















const LengkapiDataSiswaBaru = ({ token , dataAll  })=>{
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [fullName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(dataAll.full_name);
    const [id] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(dataAll.id);
    const [kpsReceiver, setKpsReceiver] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [nick_name, setNickName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [gender, setGender] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [nik, setNik] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [birth_place_date, setBirthPlaceDate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [school, setSchool] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [nisn, setNisn] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [birth_cert_no, setBirthCertNo] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [religion, setReligion] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [address, setAddress] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [rt, setRt] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [rw, setRw] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [dusun, setDusun] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [kecamatan, setKecamatan] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [transportation, setTransportation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [phone, setPhone] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(dataAll.phone);
    const [birth_date] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(dataAll.date_of_birth);
    const [kpsNumber, setKpsNumber] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [fatherName, setFatherName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [fatherNik, setFatherNik] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [fatherBirthYear, setFatherBirthYear] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [fatherEducation, setFatherEducation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [fatherIncome, setFatherIncome] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [fatherJob, setFatherJob] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [motherName, setMotherName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [motherNik, setMotherNik] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [motherBirthYear, setMotherBirthYear] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [motherEducation, setMotherEducation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [motherJob, setMotherJob] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [motherIncome, setMotherIncome] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [guardianName, setGuardianName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [guardianNik, setGuardianNik] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [guardianBirthYear, setGuardianBirthYear] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [guardianEducation, setGuardianEducation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [guardianJob, setGuardianJob] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [guardianIncome, setGuardianIncome] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [homePhone, setHomePhone] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [mobilePhone, setMobilePhone] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(dataAll.email);
    const [height, setHeight] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [weight, setWeight] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [distanceToSchool, setDistanceToSchool] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [distanceInKm, setDistanceInKm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [siblings, setSiblings] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [travelHours, setTravelHours] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [travelMinutes, setTravelMinutes] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [kartuKeluarga, setKartuKeluarga] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [akteLahir, setAkteLahir] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [ktpOrangtua, setKtpOrangtua] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [ijasah, setIjasah] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [isUpdate, setIsUpdate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false) // State to toggle between Save and Update
    ;
    const [openDialog, setOpenDialog] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedImage, setSelectedImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    function formatDate(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, "0");
        const month = String(date.getMonth() + 1).padStart(2, "0") // Bulan mulai dari 0 di JavaScript
        ;
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }
    const handleChange = (event)=>{
        setKpsReceiver(event.target.value);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_14__/* ["default"].post */ .Z.post("/detailCalonSiswaBaru", {
            uid: token
        }, {
            headers: {
                Accept: "application/json",
                Authorization: `Bearer ${token}`
            }
        }).then((response)=>{
            console.log(response.data);
            const { nick_name , gender , nik , birth_place_date , school , nisn , birth_cert_no , religion , address , rt , rw , dusun , kecamatan , transportation , phone , kps_receiver , kps_number , father_name , father_nik , father_birth_year , father_education , father_income , father_job , mother_name , mother_nik , mother_birth_year , mother_education , mother_job , mother_income , guardian_name , guardian_nik , guardian_birth_year , guardian_education , guardian_job , guardian_income , home_phone , mobile_phone , height , weight , distance_to_school , distance_in_km , siblings , travel_hours , travel_minutes , kartu_keluarga , akte_lahir , ktp_orangtua , ijasah  } = response.data;
            setNickName(nick_name);
            setGender(gender);
            setNik(nik);
            setBirthPlaceDate(birth_place_date);
            setSchool(school);
            setNisn(nisn);
            setBirthCertNo(birth_cert_no);
            setReligion(religion);
            setAddress(address);
            setRt(rt);
            setRw(rw);
            setDusun(dusun);
            setKecamatan(kecamatan);
            setTransportation(transportation);
            setPhone(phone);
            setKpsReceiver(kps_receiver);
            setKpsNumber(kps_number);
            // Set father's details
            setFatherName(father_name);
            setFatherNik(father_nik);
            setFatherBirthYear(father_birth_year);
            setFatherEducation(father_education);
            setFatherIncome(father_income);
            setFatherJob(father_job);
            // Set mother's details
            setMotherName(mother_name);
            setMotherNik(mother_nik);
            setMotherBirthYear(mother_birth_year);
            setMotherEducation(mother_education);
            setMotherJob(mother_job);
            setMotherIncome(mother_income);
            // Set guardian's details
            setGuardianName(guardian_name);
            setGuardianNik(guardian_nik);
            setGuardianBirthYear(guardian_birth_year);
            setGuardianEducation(guardian_education);
            setGuardianJob(guardian_job);
            setGuardianIncome(guardian_income);
            // Set additional fields
            setHomePhone(home_phone);
            setMobilePhone(mobile_phone);
            setHeight(height);
            setWeight(weight);
            setDistanceToSchool(distance_to_school);
            setDistanceInKm(distance_in_km);
            setSiblings(siblings);
            setTravelHours(travel_hours);
            setTravelMinutes(travel_minutes);
            setKartuKeluarga(kartu_keluarga);
            setAkteLahir(akte_lahir);
            setKtpOrangtua(ktp_orangtua);
            setIjasah(ijasah);
        }).catch((error)=>{
            console.error("Error fetching details:", error);
        });
    }, [
        token
    ]);
    // JSON Variables
    const genderOptions = [
        {
            value: "laki-laki",
            label: "Laki-Laki"
        },
        {
            value: "perempuan",
            label: "Perempuan"
        }
    ];
    const religionOptions = [
        {
            value: "islam",
            label: "Islam"
        },
        {
            value: "kristen",
            label: "Kristen"
        },
        {
            value: "hindu",
            label: "Hindu"
        },
        {
            value: "buddha",
            label: "Buddha"
        },
        {
            value: "lainnya",
            label: "Lainnya"
        }
    ];
    const motherJobOptions = [
        {
            value: "wiraswasta",
            label: "Wiraswasta"
        },
        {
            value: "pegawai_negeri",
            label: "Pegawai Negeri"
        },
        {
            value: "karyawan_swasta",
            label: "Karyawan Swasta"
        },
        {
            value: "petani",
            label: "Petani"
        },
        {
            value: "lainnya",
            label: "Lainnya"
        }
    ];
    const motherEducationOptions = [
        {
            value: "sd",
            label: "SD"
        },
        {
            value: "smp",
            label: "SMP"
        },
        {
            value: "sma",
            label: "SMA / Sederajat"
        },
        {
            value: "diploma",
            label: "Diploma"
        },
        {
            value: "sarjana",
            label: "Sarjana"
        },
        {
            value: "pasca_sarjana",
            label: "Pasca Sarjana"
        },
        {
            value: "lainnya",
            label: "Lainnya"
        }
    ];
    const guardianJobOptions = [
        {
            value: "wiraswasta",
            label: "Wiraswasta"
        },
        {
            value: "pegawai_negeri",
            label: "Pegawai Negeri"
        },
        {
            value: "karyawan_swasta",
            label: "Karyawan Swasta"
        },
        {
            value: "petani",
            label: "Petani"
        },
        {
            value: "lainnya",
            label: "Lainnya"
        }
    ];
    const guardianEducationOptions = [
        {
            value: "sd",
            label: "SD"
        },
        {
            value: "smp",
            label: "SMP"
        },
        {
            value: "sma",
            label: "SMA / Sederajat"
        },
        {
            value: "diploma",
            label: "Diploma"
        },
        {
            value: "sarjana",
            label: "Sarjana"
        },
        {
            value: "pasca_sarjana",
            label: "Pasca Sarjana"
        },
        {
            value: "lainnya",
            label: "Lainnya"
        }
    ];
    const transportasi = [
        {
            value: "Sepeda Motor",
            label: "Sepeda Motor"
        },
        {
            value: "Mobil",
            label: "Mobil"
        },
        {
            value: "Sepeda",
            label: "Sepeda"
        },
        {
            value: "Bus",
            label: "Bus"
        },
        {
            value: "Kereta",
            label: "Kereta"
        },
        {
            value: "Pesawat",
            label: "Pesawat"
        },
        {
            value: "Kapal",
            label: "Kapal"
        },
        {
            value: "Lainnya",
            label: "Lainnya"
        }
    ];
    const handleFormSubmit = (e)=>{
        console.log(motherBirthYear);
        e.preventDefault();
        setLoading(true);
        // Submit form logic here...
        setLoading(false);
        setIsUpdate(true) // Show Update button
        ;
        const formData = new FormData();
        // Append basic student data
        formData.append("fullName", fullName || "");
        formData.append("id", id || "");
        formData.append("kpsReceiver", kpsReceiver);
        formData.append("nick_name", nick_name);
        formData.append("gender", gender);
        formData.append("nik", nik);
        formData.append("birth_place_date", birth_place_date);
        formData.append("school", school);
        formData.append("nisn", nisn);
        formData.append("birth_cert_no", birth_cert_no);
        formData.append("religion", religion);
        formData.append("address", address);
        formData.append("rt", rt);
        formData.append("rw", rw);
        formData.append("dusun", dusun);
        formData.append("kecamatan", kecamatan);
        formData.append("transportation", transportation);
        formData.append("phone", dataAll.phone);
        formData.append("birth_date", birth_date);
        formData.append("kpsNumber", kpsNumber || "");
        // Append father's data
        formData.append("fatherName", fatherName);
        formData.append("fatherNik", fatherNik);
        formData.append("fatherBirthYear", fatherBirthYear);
        formData.append("fatherEducation", fatherEducation);
        formData.append("fatherIncome", fatherIncome);
        formData.append("fatherJob", fatherJob);
        // Append mother's data
        formData.append("motherName", motherName);
        formData.append("motherNik", motherNik);
        formData.append("motherBirthYear", motherBirthYear);
        formData.append("motherEducation", motherEducation);
        formData.append("motherJob", motherJob);
        formData.append("motherIncome", motherIncome);
        // Append guardian's data
        formData.append("guardianName", guardianName);
        formData.append("guardianNik", guardianNik);
        formData.append("guardianBirthYear", guardianBirthYear);
        formData.append("guardianEducation", guardianEducation);
        formData.append("guardianJob", guardianJob);
        formData.append("guardianIncome", guardianIncome);
        // Append contact details
        formData.append("homePhone", homePhone);
        formData.append("mobilePhone", mobilePhone);
        formData.append("email", dataAll.email);
        // Append physical information
        formData.append("height", height);
        formData.append("weight", weight);
        formData.append("distanceToSchool", distanceToSchool);
        formData.append("distanceInKm", distanceInKm);
        formData.append("siblings", siblings);
        formData.append("travelHours", travelHours);
        formData.append("travelMinutes", travelMinutes);
        formData.append("school_id", dataAll.school_id);
        console.log(kartuKeluarga);
        console.log(akteLahir);
        // Append file uploads
        if (kartuKeluarga) formData.append("kartuKeluarga", kartuKeluarga);
        if (akteLahir) formData.append("akteLahir", akteLahir);
        if (ktpOrangtua) formData.append("ktpOrangtua", ktpOrangtua);
        if (ijasah) formData.append("ijasah", ijasah);
        console.log(Object.fromEntries(formData.entries()));
        src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_14__/* ["default"].post */ .Z.post("/sendDataSiswaBaruAll", formData, {
            headers: {
                "Content-Type": "multipart/form-data",
                Authorization: `Bearer ${token}` // Assuming token is available
            }
        }).then((response)=>{
            console.log("Form submitted successfully:", response.data);
            sweetalert2__WEBPACK_IMPORTED_MODULE_13___default().fire({
                title: "Registrasi Siswa Baru Berhasil",
                text: "Segera cek nomor wa anda untuk melakukan proses pembayaran.",
                icon: "success",
                confirmButtonText: "OK"
            });
        }).catch((error)=>{
            console.error("Error submitting form:", error);
            sweetalert2__WEBPACK_IMPORTED_MODULE_13___default().fire({
                title: "Error",
                text: "Terjadi kesalahan saat registrasi, silakan coba lagi.",
                icon: "error",
                confirmButtonText: "OK"
            });
        }).finally(()=>{
            setLoading(false) // Set loading to false after submission completes
            ;
        });
    };
    const handleUpdateClick = ()=>{
        setIsUpdate(false) // Hide the Update button
        ;
    };
    const formatRupiah = (value)=>{
        const numberString = value.replace(/[^,\d]/g, "").toString();
        const split = numberString.split(",");
        const sisa = split[0].length % 3;
        let rupiah = split[0].substr(0, sisa);
        const ribuan = split[0].substr(sisa).match(/\d{3}/gi);
        if (ribuan) {
            const separator = sisa ? "." : "";
            rupiah += separator + ribuan.join(".");
        }
        rupiah = split[1] !== undefined ? rupiah + "," + split[1] : rupiah;
        return "Rp " + rupiah;
    };
    const renderUploadedFile = (file)=>{
        const existingFilePath = "";
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: file ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: file.name
                    }),
                    file.type && file.type.startsWith("image/") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: URL.createObjectURL(file),
                        alt: file.name,
                        style: {
                            width: "100px",
                            marginTop: "10px"
                        }
                    })
                ]
            }) : existingFilePath && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: `${src_configs_url_image__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z}/${existingFilePath}`,
                alt: "Existing file",
                style: {
                    width: "100px",
                    marginTop: "10px"
                }
            })
        });
    };
    const handleClickOpen = (imageUrl)=>{
        setSelectedImage(imageUrl);
        setOpenDialog(true);
    };
    const handleClose = ()=>{
        setOpenDialog(false);
        setSelectedImage(null);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Card__WEBPACK_IMPORTED_MODULE_2___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7___default()), {
                title: "IDENTITAS PESERTA DIDIK"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_5___default()), {
                sx: {
                    m: "0 !important"
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                onSubmit: handleFormSubmit,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_9___default()), {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                            spacing: 1,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Accordion, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionSummary, {
                                            expandIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_15__.GridExpandMoreIcon, {}),
                                            "aria-controls": "panel1a-content",
                                            id: "panel1a-header",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                variant: "body1",
                                                sx: {
                                                    fontWeight: 600
                                                },
                                                children: "A. Data Pribadi"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionDetails, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                container: true,
                                                spacing: 2,
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                                fullWidth: true,
                                                                name: "id",
                                                                value: id,
                                                                placeholder: "ABDU KHOR",
                                                                style: {
                                                                    display: id ? "none" : "block"
                                                                }
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                                fullWidth: true,
                                                                label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    children: "Nama Lengkap"
                                                                }),
                                                                name: "fullName",
                                                                value: fullName,
                                                                placeholder: "ABDU KHOR",
                                                                required: true,
                                                                InputProps: {
                                                                    readOnly: true
                                                                }
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Nama Panggilan"
                                                            }),
                                                            name: "nickName",
                                                            placeholder: "Panggilan",
                                                            value: nick_name,
                                                            onChange: (e)=>setNickName(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Jenis Kelamin"
                                                            }),
                                                            name: "gender",
                                                            placeholder: "Pilih Jenis Kelamin",
                                                            select: true,
                                                            value: gender,
                                                            onChange: (e)=>setGender(e.target.value),
                                                            required: true,
                                                            children: genderOptions.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                    value: option.value,
                                                                    children: option.label
                                                                }, option.value))
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "NIK"
                                                            }),
                                                            name: "nik",
                                                            value: nik,
                                                            placeholder: "6301080809160001",
                                                            onChange: (e)=>{
                                                                const value = e.target.value.replace(/[^0-9]/g, "");
                                                                if (value.length <= 16) {
                                                                    setNik(value);
                                                                }
                                                            },
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Tempat dan Tanggal Lahir"
                                                            }),
                                                            name: "birthPlaceDate",
                                                            placeholder: "TANAH LAUT",
                                                            value: birth_place_date,
                                                            onChange: (e)=>setBirthPlaceDate(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Asal Sekolah"
                                                            }),
                                                            name: "school",
                                                            placeholder: "Nama Sekolah",
                                                            value: school,
                                                            onChange: (e)=>setSchool(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "NISN"
                                                            }),
                                                            name: "nisn",
                                                            placeholder: "0166235335",
                                                            value: nisn,
                                                            onChange: (e)=>setNisn(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "No. Registrasi Akta Lahir"
                                                            }),
                                                            name: "birthCertNo",
                                                            placeholder: "123456789",
                                                            value: birth_cert_no,
                                                            onChange: (e)=>setBirthCertNo(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Agama"
                                                            }),
                                                            name: "religion",
                                                            placeholder: "Pilih Agama",
                                                            value: religion,
                                                            select: true,
                                                            onChange: (e)=>setReligion(e.target.value),
                                                            required: true,
                                                            children: religionOptions.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                    value: option.value,
                                                                    children: option.label
                                                                }, option.value))
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Alamat Tempat Tinggal"
                                                            }),
                                                            name: "address",
                                                            placeholder: "JL ABADI MAKMUR / GUNTUNG KEMINTING",
                                                            value: address,
                                                            onChange: (e)=>setAddress(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 3,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "RT"
                                                            }),
                                                            name: "rt",
                                                            placeholder: "RT",
                                                            value: rt,
                                                            onInput: (e)=>{
                                                                const value = e.target.value.replace(/[^0-9]/g, "");
                                                                if (!e.target.value.startsWith("RT")) {
                                                                    e.target.value = "RT ";
                                                                } else {
                                                                    e.target.value = `RT ${value}`;
                                                                }
                                                                setRt(e.target.value) // Set the RT value
                                                                ;
                                                            },
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 3,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "RW"
                                                            }),
                                                            name: "rw",
                                                            placeholder: "RW",
                                                            value: rw,
                                                            onInput: (e)=>{
                                                                const value = e.target.value.replace(/[^0-9]/g, "");
                                                                if (!e.target.value.startsWith("RW")) {
                                                                    e.target.value = "RW ";
                                                                } else {
                                                                    e.target.value = `RW ${value}`;
                                                                }
                                                                setRw(e.target.value) // Set the RW value
                                                                ;
                                                            },
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Nama Dusun"
                                                            }),
                                                            name: "dusun",
                                                            placeholder: "Dusun XYZ",
                                                            value: dusun,
                                                            onChange: (e)=>setDusun(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Kecamatan"
                                                            }),
                                                            name: "kecamatan",
                                                            placeholder: "Kec. Banjarbaru Selatan",
                                                            value: kecamatan,
                                                            onChange: (e)=>setKecamatan(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Transportasi"
                                                            }),
                                                            name: "transportation",
                                                            placeholder: "Pilih Transportasi",
                                                            value: transportation,
                                                            select: true,
                                                            onChange: (e)=>setTransportation(e.target.value),
                                                            required: true,
                                                            children: transportasi.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                    value: option.value,
                                                                    children: option.label
                                                                }, option.value))
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "No. Telepon"
                                                            }),
                                                            name: "phone",
                                                            placeholder: "62-123-456-7890",
                                                            onInput: (e)=>{
                                                                const value = e.target.value.replace(/[^0-9]/g, "");
                                                                if (!value.startsWith("62")) {
                                                                    e.target.value = "62";
                                                                } else {
                                                                    e.target.value = value;
                                                                }
                                                                setPhone(e.target.value) // Set the RW value
                                                                ;
                                                            },
                                                            value: phone,
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Date of Birth",
                                                            value: formatDate(birth_date),
                                                            placeholder: "YYYY-MM-DD",
                                                            InputProps: {
                                                                readOnly: true
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            container: true,
                                                            spacing: 2,
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                    item: true,
                                                                    xs: 3,
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.FormControl, {
                                                                        component: "fieldset",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.FormLabel, {
                                                                                component: "legend",
                                                                                children: "Apakah Penerima KPS"
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.FormGroup, {
                                                                                row: true,
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.FormControlLabel, {
                                                                                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Checkbox, {
                                                                                            name: "kpsReceiver",
                                                                                            checked: kpsReceiver === "ya",
                                                                                            onChange: handleChange,
                                                                                            value: "ya"
                                                                                        }),
                                                                                        label: "Ya"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.FormControlLabel, {
                                                                                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Checkbox, {
                                                                                            name: "kpsReceiver",
                                                                                            checked: kpsReceiver === "tidak",
                                                                                            onChange: handleChange,
                                                                                            value: "tidak"
                                                                                        }),
                                                                                        label: "Tidak"
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                kpsReceiver === "ya" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                    item: true,
                                                                    xs: 9,
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                                        fullWidth: true,
                                                                        label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            children: "No. KPS"
                                                                        }),
                                                                        name: "kpsNumber",
                                                                        placeholder: "123-456-7890",
                                                                        value: kpsNumber,
                                                                        onChange: (e)=>setKpsNumber(e.target.value)
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Accordion, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionSummary, {
                                            expandIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_15__.GridExpandMoreIcon, {}),
                                            "aria-controls": "panel2a-content",
                                            id: "panel2a-header",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                variant: "body1",
                                                sx: {
                                                    fontWeight: 600
                                                },
                                                children: "B. Data Ayah Kandung"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionDetails, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                container: true,
                                                spacing: 3,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Nama",
                                                            name: "fatherName",
                                                            placeholder: "",
                                                            required: true,
                                                            value: fatherName,
                                                            onChange: (e)=>setFatherName(e.target.value)
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "NIK Ayah",
                                                            name: "fatherNik",
                                                            placeholder: "",
                                                            required: true,
                                                            value: fatherNik,
                                                            onChange: (e)=>{
                                                                const value = e.target.value.replace(/[^0-9]/g, "");
                                                                if (value.length <= 16) {
                                                                    setFatherNik(value) // Update the state value
                                                                    ;
                                                                }
                                                            },
                                                            inputProps: {
                                                                maxLength: 16
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Tahun Lahir",
                                                            name: "fatherBirthYear",
                                                            placeholder: "",
                                                            required: true,
                                                            value: fatherBirthYear,
                                                            onChange: (e)=>{
                                                                const value = e.target.value;
                                                                if (/^\d{0,4}$/.test(value)) {
                                                                    setFatherBirthYear(value);
                                                                }
                                                            },
                                                            inputProps: {
                                                                maxLength: 4
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Pendidikan",
                                                            name: "fatherEducation",
                                                            placeholder: "Pilih Pendidikan",
                                                            select: true,
                                                            required: true,
                                                            value: fatherEducation,
                                                            onChange: (e)=>setFatherEducation(e.target.value),
                                                            children: motherEducationOptions.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                    value: option.value,
                                                                    children: option.label
                                                                }, option.value))
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Penghasilan",
                                                            name: "fatherIncome",
                                                            placeholder: "",
                                                            required: true,
                                                            value: fatherIncome,
                                                            onChange: (e)=>{
                                                                const rawValue = e.target.value.replace(/[^0-9]/g, "");
                                                                setFatherIncome(formatRupiah(rawValue));
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Pekerjaan",
                                                            name: "fatherJob",
                                                            placeholder: "Pilih Pekerjaan",
                                                            select: true,
                                                            required: true,
                                                            value: fatherJob,
                                                            onChange: (e)=>setFatherJob(e.target.value),
                                                            children: motherJobOptions.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                    value: option.value,
                                                                    children: option.label
                                                                }, option.value))
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Accordion, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionSummary, {
                                            expandIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_15__.GridExpandMoreIcon, {}),
                                            "aria-controls": "panel3a-content",
                                            id: "panel3a-header",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                variant: "body1",
                                                sx: {
                                                    fontWeight: 600
                                                },
                                                children: "C. Data Ibu Kandung"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionDetails, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                container: true,
                                                spacing: 3,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Nama",
                                                            name: "motherName",
                                                            placeholder: "SHELA WATI",
                                                            value: motherName,
                                                            onChange: (e)=>setMotherName(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "NIK Ibu",
                                                            name: "motherNik",
                                                            placeholder: "",
                                                            value: motherNik,
                                                            onChange: (e)=>{
                                                                const value = e.target.value.replace(/[^0-9]/g, "");
                                                                if (value.length <= 16) {
                                                                    setMotherNik(value);
                                                                }
                                                            },
                                                            inputProps: {
                                                                maxLength: 16
                                                            },
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Tahun Lahir",
                                                            name: "motherBirthYear",
                                                            placeholder: "1994",
                                                            value: motherBirthYear,
                                                            onChange: (e)=>{
                                                                const value = e.target.value;
                                                                if (/^\d{0,4}$/.test(value)) {
                                                                    setMotherBirthYear(value);
                                                                }
                                                            },
                                                            inputProps: {
                                                                maxLength: 4
                                                            },
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Pendidikan terakhir",
                                                            name: "motherEducation",
                                                            placeholder: "Pilih Pendidikan",
                                                            select: true,
                                                            value: motherEducation,
                                                            onChange: (e)=>setMotherEducation(e.target.value),
                                                            required: true,
                                                            children: motherEducationOptions.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                    value: option.value,
                                                                    children: option.label
                                                                }, option.value))
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Pekerjaan",
                                                            name: "motherJob",
                                                            placeholder: "Pilih Pekerjaan",
                                                            select: true,
                                                            value: motherJob,
                                                            onChange: (e)=>setMotherJob(e.target.value),
                                                            required: true,
                                                            children: motherJobOptions.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                    value: option.value,
                                                                    children: option.label
                                                                }, option.value))
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Penghasilan Bulanan",
                                                            name: "motherIncome",
                                                            placeholder: "Tidak Berpenghasilan",
                                                            value: motherIncome,
                                                            onInput: (e)=>{
                                                                const rawValue = e.target.value.replace(/[^0-9]/g, "");
                                                                setMotherIncome(formatRupiah(rawValue));
                                                            },
                                                            required: true
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Accordion, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionSummary, {
                                            expandIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_15__.GridExpandMoreIcon, {}),
                                            "aria-controls": "panel4a-content",
                                            id: "panel4a-header",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                variant: "body1",
                                                sx: {
                                                    fontWeight: 600
                                                },
                                                children: "D. Data Wali"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionDetails, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                container: true,
                                                spacing: 3,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Nama",
                                                            name: "guardianName",
                                                            placeholder: "Masukkan Nama Wali",
                                                            value: guardianName,
                                                            onChange: (e)=>setGuardianName(e.target.value)
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "NIK Wali",
                                                            name: "guardianNik",
                                                            placeholder: "Masukkan NIK Wali",
                                                            value: guardianNik,
                                                            onChange: (e)=>{
                                                                const value = e.target.value.replace(/[^0-9]/g, "");
                                                                if (value.length <= 16) {
                                                                    setGuardianNik(value);
                                                                }
                                                            },
                                                            inputProps: {
                                                                maxLength: 16
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Tahun Lahir",
                                                            name: "guardianBirthYear",
                                                            placeholder: "Masukkan Tahun Lahir",
                                                            value: guardianBirthYear,
                                                            onChange: (e)=>{
                                                                const value = e.target.value;
                                                                if (/^\d{0,4}$/.test(value)) {
                                                                    setGuardianBirthYear(value);
                                                                }
                                                            },
                                                            inputProps: {
                                                                maxLength: 4
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Pendidikan Terakhir",
                                                            name: "guardianEducation",
                                                            placeholder: "Pilih Pendidikan Terakhir",
                                                            select: true,
                                                            value: guardianEducation,
                                                            onChange: (e)=>setGuardianEducation(e.target.value),
                                                            children: guardianEducationOptions.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                    value: option.value,
                                                                    children: option.label
                                                                }, option.value))
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Pekerjaan",
                                                            name: "guardianJob",
                                                            placeholder: "Pilih Pekerjaan",
                                                            select: true,
                                                            value: guardianJob,
                                                            onChange: (e)=>setGuardianJob(e.target.value),
                                                            children: guardianJobOptions.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                    value: option.value,
                                                                    children: option.label
                                                                }, option.value))
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Penghasilan",
                                                            name: "guardianIncome",
                                                            placeholder: "Masukkan Penghasilan",
                                                            value: guardianIncome,
                                                            onInput: (e)=>{
                                                                const rawValue = e.target.value.replace(/[^0-9]/g, "");
                                                                setGuardianIncome(formatRupiah(rawValue));
                                                            }
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Accordion, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionSummary, {
                                            expandIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_15__.GridExpandMoreIcon, {}),
                                            "aria-controls": "panel5a-content",
                                            id: "panel5a-header",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                variant: "body1",
                                                sx: {
                                                    fontWeight: 600
                                                },
                                                children: "E. Kontak"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionDetails, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                container: true,
                                                spacing: 3,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 4,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Nomor Telepon Rumah",
                                                            name: "homePhone",
                                                            placeholder: "",
                                                            value: homePhone,
                                                            onInput: (e)=>{
                                                                const value = e.target.value.replace(/[^0-9]/g, "") // Remove non-numeric characters
                                                                ;
                                                                setHomePhone(value) // Update the state with the cleaned value
                                                                ;
                                                            },
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 4,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Nomor HP",
                                                            name: "mobilePhone",
                                                            placeholder: "",
                                                            value: mobilePhone,
                                                            onInput: (e)=>{
                                                                let value = e.target.value.replace(/[^0-9]/g, "") // Remove non-numeric characters
                                                                ;
                                                                if (!value.startsWith("62")) {
                                                                    value = "62" + value // Set default to '62' if not starting with it
                                                                    ;
                                                                }
                                                                setMobilePhone(value) // Update the state with the cleaned and formatted value
                                                                ;
                                                            },
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 4,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "E-mail",
                                                            name: "email",
                                                            placeholder: "",
                                                            value: email,
                                                            onChange: (e)=>setEmail(e.target.value),
                                                            required: true
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Accordion, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionSummary, {
                                            expandIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_15__.GridExpandMoreIcon, {}),
                                            "aria-controls": "panel6a-content",
                                            id: "panel6a-header",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                variant: "body1",
                                                sx: {
                                                    fontWeight: 600
                                                },
                                                children: "F. Data Pribadi"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionDetails, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                container: true,
                                                spacing: 3,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 4,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Tinggi Badan (cm)",
                                                            name: "height",
                                                            placeholder: "Masukkan tinggi badan dalam cm",
                                                            type: "number",
                                                            value: height,
                                                            onChange: (e)=>setHeight(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 4,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Berat Badan (kg)",
                                                            name: "weight",
                                                            placeholder: "Masukkan berat badan dalam kg",
                                                            type: "number",
                                                            value: weight,
                                                            onChange: (e)=>setWeight(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 4,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                                variant: "body1",
                                                                children: "Jarak rumah ke sekolah:"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.RadioGroup, {
                                                                row: true,
                                                                name: "distanceToSchool",
                                                                value: distanceToSchool,
                                                                onChange: (e)=>setDistanceToSchool(e.target.value),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.FormControlLabel, {
                                                                        value: "kurang1km",
                                                                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Radio, {}),
                                                                        label: "Kurang dari 1 KM"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.FormControlLabel, {
                                                                        value: "lebih1km",
                                                                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Radio, {}),
                                                                        label: "Lebih dari 1 KM"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Sebutkan dalam kilometer",
                                                            name: "distanceInKm",
                                                            placeholder: "Masukkan jarak dalam km",
                                                            type: "number",
                                                            value: distanceInKm,
                                                            onChange: (e)=>setDistanceInKm(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            fullWidth: true,
                                                            label: "Jumlah Saudara Kandung",
                                                            name: "siblings",
                                                            placeholder: "Masukkan jumlah saudara kandung",
                                                            type: "number",
                                                            value: siblings,
                                                            onChange: (e)=>setSiblings(e.target.value),
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        container: true,
                                                        spacing: 2,
                                                        item: true,
                                                        xs: 12,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                                variant: "body1",
                                                                children: "Waktu Tempuh:"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                container: true,
                                                                item: true,
                                                                xs: 12,
                                                                spacing: 2,
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                        item: true,
                                                                        xs: 6,
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                                            fullWidth: true,
                                                                            label: "Jam",
                                                                            name: "travelHours",
                                                                            placeholder: "",
                                                                            type: "number",
                                                                            inputProps: {
                                                                                min: 0,
                                                                                max: 23
                                                                            },
                                                                            value: travelHours,
                                                                            onInput: (e)=>{
                                                                                let value = parseInt(e.target.value, 10);
                                                                                if (value < 0) value = 0;
                                                                                if (value > 23) value = 23;
                                                                                setTravelHours(value.toString());
                                                                            },
                                                                            required: true
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                        item: true,
                                                                        xs: 6,
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                                            fullWidth: true,
                                                                            label: "Menit",
                                                                            name: "travelMinutes",
                                                                            placeholder: "",
                                                                            type: "number",
                                                                            inputProps: {
                                                                                min: 0,
                                                                                max: 59
                                                                            },
                                                                            value: travelMinutes,
                                                                            onInput: (e)=>{
                                                                                let value = parseInt(e.target.value, 10);
                                                                                if (value < 0) value = 0;
                                                                                if (value > 59) value = 59;
                                                                                setTravelMinutes(value.toString());
                                                                            },
                                                                            required: true
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Accordion, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionSummary, {
                                            expandIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_15__.GridExpandMoreIcon, {}),
                                            "aria-controls": "panel7a-content",
                                            id: "panel7a-header",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                variant: "body1",
                                                sx: {
                                                    fontWeight: 600
                                                },
                                                children: "G. Upload Data"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.AccordionDetails, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                container: true,
                                                spacing: 3,
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 3,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                                fullWidth: true,
                                                                label: "Upload Kartu Keluarga",
                                                                name: "kartuKeluarga",
                                                                type: "file",
                                                                onChange: (e)=>setKartuKeluarga(e.target.files?.[0])
                                                            }),
                                                            kartuKeluarga && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    renderUploadedFile(kartuKeluarga),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        src: `${src_configs_url_image__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z}${kartuKeluarga}`,
                                                                        style: {
                                                                            width: "100px",
                                                                            marginTop: "10px",
                                                                            cursor: "pointer"
                                                                        },
                                                                        onClick: ()=>handleClickOpen(`${src_configs_url_image__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z}${kartuKeluarga}`),
                                                                        alt: "Kartu Keluarga"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 3,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                                fullWidth: true,
                                                                label: "Upload Akte Lahir",
                                                                name: "akteLahir",
                                                                type: "file",
                                                                onChange: (e)=>setAkteLahir(e.target.files?.[0])
                                                            }),
                                                            akteLahir && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    renderUploadedFile(akteLahir),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        src: `${src_configs_url_image__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z}${akteLahir}`,
                                                                        style: {
                                                                            width: "100px",
                                                                            marginTop: "10px",
                                                                            cursor: "pointer"
                                                                        },
                                                                        onClick: ()=>handleClickOpen(`${src_configs_url_image__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z}${akteLahir}`),
                                                                        alt: "Akte Lahir"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 3,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                                fullWidth: true,
                                                                label: "Upload KTP Orangtua",
                                                                name: "ktpOrangtua",
                                                                type: "file",
                                                                onChange: (e)=>setKtpOrangtua(e.target.files?.[0])
                                                            }),
                                                            ktpOrangtua && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    renderUploadedFile(ktpOrangtua),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        src: `${src_configs_url_image__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z}${ktpOrangtua}`,
                                                                        style: {
                                                                            width: "100px",
                                                                            marginTop: "10px",
                                                                            cursor: "pointer"
                                                                        },
                                                                        onClick: ()=>handleClickOpen(`${src_configs_url_image__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z}${ktpOrangtua}`),
                                                                        alt: "KTP Orangtua"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        item: true,
                                                        xs: 3,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_text_field__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                                fullWidth: true,
                                                                label: "Upload Ijazah",
                                                                name: "ijasah",
                                                                type: "file",
                                                                onChange: (e)=>setIjasah(e.target.files?.[0])
                                                            }),
                                                            ijasah && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    renderUploadedFile(ijasah),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        src: `${src_configs_url_image__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z}${ijasah}`,
                                                                        style: {
                                                                            width: "100px",
                                                                            marginTop: "10px",
                                                                            cursor: "pointer"
                                                                        },
                                                                        onClick: ()=>handleClickOpen(`${src_configs_url_image__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z}${ijasah}`),
                                                                        alt: "Ijazah"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CardActions__WEBPACK_IMPORTED_MODULE_10___default()), {
                        children: !isUpdate ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_4___default()), {
                            onClick: (e)=>handleFormSubmit(e),
                            sx: {
                                mr: 2
                            },
                            variant: "contained",
                            color: "error",
                            children: "Simpan"
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_4___default()), {
                            onClick: (e)=>{
                                handleFormSubmit(e), handleUpdateClick;
                            },
                            sx: {
                                mr: 2
                            },
                            variant: "contained",
                            color: "primary",
                            children: "Update"
                        })
                    })
                ]
            }),
            loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Box, {
                sx: {
                    position: "fixed",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: "rgba(0, 0, 0, 0.5)",
                    zIndex: 9999
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.CircularProgress, {
                    color: "primary"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Dialog, {
                open: openDialog,
                onClose: handleClose,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.DialogTitle, {
                        children: "Image Preview"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.DialogContent, {
                        children: selectedImage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: selectedImage,
                            style: {
                                width: "100%"
                            },
                            alt: "Preview"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LengkapiDataSiswaBaru);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;