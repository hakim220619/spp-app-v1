"use strict";
exports.id = 2180;
exports.ids = [2180];
exports.modules = {

/***/ 2026:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_0__);
// ** Next Import

// ! To avoid 'Window is not defined' error
const ReactApexcharts = next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\@core\\components\\react-apexcharts\\index.tsx -> " + "react-apexcharts"
        ]
    },
    ssr: false
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReactApexcharts);


/***/ }),

/***/ 2180:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8167);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Card__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8455);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_core_components_react_apexcharts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2026);
/* harmony import */ var src_core_utils_hex_to_rgba__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5812);
/* harmony import */ var src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7740);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_7__]);
src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// ** MUI Imports





 // Import useEffect and useState
// ** Custom Components Imports

// ** Util Import


const series = [
    {
        data: [
            12,
            12,
            18,
            18,
            13,
            13,
            5,
            5,
            17,
            17,
            25,
            25
        ]
    }
];
const SaldoBySchool = ()=>{
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    // State to hold school name
    const [schoolName, setSchoolName] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("Sekolah") // Default fallback value
    ;
    const [totalSaldoBySchool, setTotalPembayaranBulanan] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(null);
    const [totalTransaksiBySchool, setTotalTransaksiBySchool] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(null);
    // useEffect to fetch data from local storage
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        const data = localStorage.getItem("userData");
        const getDataLocal = JSON.parse(data);
        const storedToken = window.localStorage.getItem("token");
        const fetchGetSaldoBySchool = async ()=>{
            try {
                const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_7__/* ["default"].get */ .Z.get("/get-saldo-bySchool", {
                    headers: {
                        Accept: "application/json",
                        Authorization: `Bearer ${storedToken}`
                    },
                    params: {
                        school_id: getDataLocal.school_id // Send the school_id as a query parameter
                    }
                });
                setTotalPembayaranBulanan(response.data.balance);
            } catch (error) {
                console.error("Error fetching total pembayaran:", error);
            // toast.error('Failed to fetch data. Please try again later.') // Use toast.error here
            }
        };
        const fetchGetTotalTransaski = async ()=>{
            try {
                const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_7__/* ["default"].get */ .Z.get("/get-transaski-affiliate-bySchool", {
                    headers: {
                        Accept: "application/json",
                        Authorization: `Bearer ${storedToken}`
                    },
                    params: {
                        school_id: getDataLocal.school_id // Send the school_id as a query parameter
                    }
                });
                setTotalTransaksiBySchool(response.data.total);
            } catch (error) {
                console.error("Error fetching total pembayaran:", error);
            // toast.error('Failed to fetch data. Please try again later.') // Use toast.error here
            }
        };
        if (data) {
            const getDataLocal = JSON.parse(data);
            if (getDataLocal.school_name) {
                setSchoolName(getDataLocal.school_name);
            }
        }
        fetchGetTotalTransaski();
        fetchGetSaldoBySchool();
    }, []) // Empty dependency array to run once on mount
    ;
    // Function to format number to Rupiah without decimal
    const formatRupiah = (amount)=>{
        return new Intl.NumberFormat("id-ID", {
            style: "currency",
            currency: "IDR",
            minimumFractionDigits: 0,
            maximumFractionDigits: 0 // No decimal places
        }).format(amount);
    };
    const options = {
        chart: {
            parentHeightOffset: 0,
            toolbar: {
                show: false
            },
            dropShadow: {
                top: 14,
                blur: 4,
                left: 0,
                enabled: true,
                opacity: 0.12,
                color: theme.palette.primary.main
            }
        },
        tooltip: {
            enabled: false
        },
        grid: {
            xaxis: {
                lines: {
                    show: false
                }
            },
            yaxis: {
                lines: {
                    show: false
                }
            },
            padding: {
                top: -12,
                left: -2,
                right: 8,
                bottom: -10
            }
        },
        stroke: {
            width: 5,
            lineCap: "round"
        },
        markers: {
            size: 0
        },
        colors: [
            (0,src_core_utils_hex_to_rgba__WEBPACK_IMPORTED_MODULE_8__/* .hexToRGBA */ .E)(theme.palette.primary.main, 1)
        ],
        xaxis: {
            labels: {
                show: false
            },
            axisTicks: {
                show: false
            },
            axisBorder: {
                show: false
            }
        },
        yaxis: {
            min: 0,
            labels: {
                show: false
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Card__WEBPACK_IMPORTED_MODULE_1___default()), {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_4___default()), {
            sx: {
                pb: "0 !important"
            },
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default()), {
                    variant: "h6",
                    sx: {
                        mb: 2.5
                    },
                    children: [
                        "Saldo ",
                        schoolName
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default()), {
                    variant: "body2",
                    children: "Total Saldo Aktif"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default()), {
                    variant: "h6",
                    color: "error",
                    children: formatRupiah(totalSaldoBySchool)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_react_apexcharts__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    type: "line",
                    height: totalTransaksiBySchool + 15,
                    options: options,
                    series: series
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SaldoBySchool);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;