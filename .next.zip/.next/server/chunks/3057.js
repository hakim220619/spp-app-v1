"use strict";
exports.id = 3057;
exports.ids = [3057];
exports.modules = {

/***/ 3057:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8167);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Card__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_lab_TimelineDot__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7277);
/* harmony import */ var _mui_lab_TimelineDot__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_TimelineDot__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_lab_TimelineItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4641);
/* harmony import */ var _mui_lab_TimelineItem__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_TimelineItem__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9361);
/* harmony import */ var _mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8455);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_lab_TimelineContent__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8643);
/* harmony import */ var _mui_lab_TimelineContent__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_TimelineContent__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_lab_TimelineSeparator__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2032);
/* harmony import */ var _mui_lab_TimelineSeparator__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_TimelineSeparator__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_lab_TimelineConnector__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5392);
/* harmony import */ var _mui_lab_TimelineConnector__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_TimelineConnector__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_lab_Timeline__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6964);
/* harmony import */ var _mui_lab_Timeline__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_Timeline__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var src_core_components_option_menu__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1010);
/* harmony import */ var src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7740);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_16__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_core_components_option_menu__WEBPACK_IMPORTED_MODULE_14__, src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_15__]);
([src_core_components_option_menu__WEBPACK_IMPORTED_MODULE_14__, src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














// ** Custom Components Imports



// Styled Timeline component
const Timeline = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__.styled)((_mui_lab_Timeline__WEBPACK_IMPORTED_MODULE_13___default()))({
    paddingLeft: 0,
    paddingRight: 0,
    "& .MuiTimelineItem-root": {
        width: "100%",
        "&:before": {
            display: "none"
        }
    }
});
const ITEMS_PER_PAGE = 4 // Constant for pagination limit
;
const EcommerceActivityTimeline = ()=>{
    const [activities, setActivities] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [page, setPage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1) // State for pagination
    ;
    const data = localStorage.getItem("userData");
    const getDataLocal = JSON.parse(data);
    const schoolId = getDataLocal.school_id;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchData = async ()=>{
            try {
                const token = localStorage.getItem("token") // Get token from localStorage
                ;
                const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_15__/* ["default"].get */ .Z.get(`/getActivityBySchoolId?school_id=${schoolId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                setActivities(response.data) // Assuming the data is an array of activities
                ;
            } catch (error) {
                console.error("Error fetching activities:", error);
            }
        };
        fetchData();
    }, [
        schoolId
    ]);
    // Function to format the date
    const formatDate = (dateString)=>{
        const createdAt = new Date(dateString);
        const formattedDate = createdAt.toLocaleString("sv-SE", {
            year: "numeric",
            month: "2-digit",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            hour12: false // Use 24-hour format
        });
        return formattedDate;
    };
    // Function to handle page changes
    const handlePageChange = (event, value)=>{
        setPage(value);
    };
    // Calculate the paginated activities
    const startIndex = (page - 1) * ITEMS_PER_PAGE;
    const paginatedActivities = activities.slice(startIndex, startIndex + ITEMS_PER_PAGE);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Card__WEBPACK_IMPORTED_MODULE_3___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7___default()), {
                title: "Activity Timeline",
                action: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_option_menu__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                    options: [
                        "Last 28 Days",
                        "Last Month",
                        "Last Year"
                    ],
                    iconButtonProps: {
                        size: "small",
                        className: "card-more-options"
                    }
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_9___default()), {
                sx: {
                    pt: (theme)=>`${theme.spacing(2.5)} !important`
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Timeline, {
                        sx: {
                            my: 0,
                            py: 0
                        },
                        children: paginatedActivities.map((activity, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_lab_TimelineItem__WEBPACK_IMPORTED_MODULE_6___default()), {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_lab_TimelineSeparator__WEBPACK_IMPORTED_MODULE_11___default()), {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_lab_TimelineDot__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                color: activity.action === "Insert" || activity.action === "Create" ? "success" : activity.action === "Update" ? "info" : activity.action === "Delete" ? "error" : "primary"
                                            }),
                                            index !== paginatedActivities.length - 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_lab_TimelineConnector__WEBPACK_IMPORTED_MODULE_12___default()), {})
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_lab_TimelineContent__WEBPACK_IMPORTED_MODULE_10___default()), {
                                        sx: {
                                            mt: 0,
                                            mb: (theme)=>`${theme.spacing(3)} !important`
                                        },
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                sx: {
                                                    mb: 3,
                                                    display: "flex",
                                                    flexWrap: "wrap",
                                                    alignItems: "center",
                                                    justifyContent: "space-between"
                                                },
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                        sx: {
                                                            mr: 2,
                                                            fontWeight: 600
                                                        },
                                                        children: activity.action
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                        variant: "caption",
                                                        sx: {
                                                            color: "text.disabled"
                                                        },
                                                        children: formatDate(activity.created_at)
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                variant: "body2",
                                                sx: {
                                                    mb: 2
                                                },
                                                children: activity.detail
                                            }),
                                            activity.file && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                sx: {
                                                    display: "flex",
                                                    alignItems: "center"
                                                },
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        width: 24,
                                                        height: 24,
                                                        alt: activity.fileName,
                                                        src: "/images/icons/file-icons/pdf.png"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                        variant: "subtitle2",
                                                        sx: {
                                                            ml: 2,
                                                            fontWeight: 600
                                                        },
                                                        children: activity.fileName
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }, startIndex + index))
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_16__.Pagination, {
                        count: Math.ceil(activities.length / ITEMS_PER_PAGE),
                        page: page,
                        onChange: handlePageChange,
                        sx: {
                            mt: 2,
                            display: "flex",
                            justifyContent: "center"
                        }
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EcommerceActivityTimeline);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;