"use strict";
exports.id = 3299;
exports.ids = [3299];
exports.modules = {

/***/ 3299:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_x_data_grid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7738);
/* harmony import */ var _mui_x_data_grid__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var src_core_components_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3730);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_core_components_mui_chip__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(613);
/* harmony import */ var src_store_apps_pembayaran_admin_listPayment_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7815);
/* harmony import */ var src_pages_ms_setting_pembayaran_TabelHeaderDetail__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8126);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6201);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_core_components_icon__WEBPACK_IMPORTED_MODULE_4__, src_store_apps_pembayaran_admin_listPayment_index__WEBPACK_IMPORTED_MODULE_7__, src_pages_ms_setting_pembayaran_TabelHeaderDetail__WEBPACK_IMPORTED_MODULE_8__, react_hot_toast__WEBPACK_IMPORTED_MODULE_9__]);
([src_core_components_icon__WEBPACK_IMPORTED_MODULE_4__, src_store_apps_pembayaran_admin_listPayment_index__WEBPACK_IMPORTED_MODULE_7__, src_pages_ms_setting_pembayaran_TabelHeaderDetail__WEBPACK_IMPORTED_MODULE_8__, react_hot_toast__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const statusObj = {
    Pending: {
        title: "Proses Pembayaran",
        color: "error"
    },
    Verified: {
        title: "Belum Lunas",
        color: "warning"
    },
    Paid: {
        title: "Lunas",
        color: "success"
    }
};
const typeObj = {
    BULANAN: {
        title: "BULANAN",
        color: "success"
    },
    BEBAS: {
        title: "BEBAS",
        color: "warning"
    }
};
const RowOptions = ({ uid , type , dataAll  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: type === "BULANAN" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_10___default()), {
            href: `/ms/pembayaran/admin/bulanan/${uid}?school_id=${dataAll.school_id}&user_id=${dataAll.user_id}`,
            passHref: true,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "contained",
                sx: {
                    "& svg": {
                        mr: 2
                    }
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_icon__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        fontSize: "1.125rem",
                        icon: ""
                    }),
                    "BAYAR"
                ]
            })
        }) : type === "BEBAS" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_10___default()), {
            href: `/ms/pembayaran/admin/bebas/${uid}?school_id=${dataAll.school_id}&user_id=${dataAll.user_id}`,
            passHref: true,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "contained",
                sx: {
                    "& svg": {
                        mr: 2
                    }
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_icon__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        fontSize: "1.125rem",
                        icon: ""
                    }),
                    "BAYAR"
                ]
            })
        }) : null
    });
};
const columns = [
    {
        field: "no",
        headerName: "No",
        width: 70
    },
    {
        field: "unit_name",
        headerName: "Unit",
        flex: 0.175,
        minWidth: 140
    },
    {
        field: "full_name",
        headerName: "Nama Siswa",
        flex: 0.175,
        minWidth: 140
    },
    {
        field: "sp_name",
        headerName: "Pembayaran",
        flex: 0.175,
        minWidth: 140
    },
    {
        field: "type",
        headerName: "Tipe Pembayaran",
        flex: 0.175,
        minWidth: 150,
        renderCell: (params)=>{
            const type = typeObj[params.row.type];
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_chip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                rounded: true,
                size: "small",
                skin: "light",
                color: type.color,
                label: type.title,
                sx: {
                    "& .MuiChip-label": {
                        textTransform: "capitalize"
                    }
                }
            });
        }
    },
    {
        field: "pending",
        headerName: "Tunggakan",
        flex: 0.175,
        minWidth: 140,
        valueGetter: (params)=>{
            const { row  } = params;
            return row.pending - (row.detail_verified + row.detail_paid);
        },
        valueFormatter: ({ value  })=>{
            return new Intl.NumberFormat("id-ID", {
                style: "currency",
                currency: "IDR",
                maximumFractionDigits: 0
            }).format(value);
        }
    },
    {
        field: "verified",
        headerName: "Proses Pembayaran",
        flex: 0.175,
        minWidth: 140,
        valueGetter: (params)=>{
            return params.row.type === "BULANAN" ? params.row.verified : params.row.detail_verified;
        },
        valueFormatter: ({ value  })=>{
            return new Intl.NumberFormat("id-ID", {
                style: "currency",
                currency: "IDR",
                maximumFractionDigits: 0
            }).format(value);
        }
    },
    {
        field: "paid",
        headerName: "Sudah Dibayar",
        flex: 0.175,
        minWidth: 140,
        valueGetter: (params)=>{
            return params.row.type === "BULANAN" ? params.row.paid : params.row.detail_paid;
        },
        valueFormatter: ({ value  })=>{
            return new Intl.NumberFormat("id-ID", {
                style: "currency",
                currency: "IDR",
                maximumFractionDigits: 0
            }).format(value);
        }
    },
    {
        field: "years",
        headerName: "Tahun",
        flex: 0.175,
        minWidth: 120
    },
    {
        field: "status_lunas",
        headerName: "Status",
        flex: 0.175,
        minWidth: 140,
        renderCell: (params)=>{
            const statusKey = params.row.type === "BULANAN" ? "status_lunas" : "status_lunas_detail";
            const status = statusObj[params.row[statusKey]];
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_chip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                rounded: true,
                size: "small",
                skin: "light",
                color: status?.color,
                label: status?.title,
                sx: {
                    "& .MuiChip-label": {
                        textTransform: "capitalize"
                    }
                }
            });
        }
    },
    {
        flex: 0,
        minWidth: 200,
        sortable: false,
        field: "actions",
        headerName: "Actions",
        renderCell: ({ row  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RowOptions, {
                uid: row.uid,
                type: row.type,
                dataAll: row
            })
    }
];
const TabelPaymentMonth = ({ school_id , unit_id , uid  })=>{
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [paginationModel, setPaginationModel] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        page: 0,
        pageSize: 10
    });
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    const store = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.ListPaymentDashboardByMonthAdmin);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchData = async ()=>{
            setLoading(true);
            try {
                await new Promise((resolve)=>setTimeout(resolve, 1000));
                await dispatch((0,src_store_apps_pembayaran_admin_listPayment_index__WEBPACK_IMPORTED_MODULE_7__/* .ListPaymentDashboardByMonthAdmin */ .p2)({
                    school_id,
                    unit_id,
                    user_id: uid,
                    q: value
                }));
            } catch (error) {
                console.error("Error fetching data:", error);
                react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].error("Failed to fetch data. Please try again.");
            } finally{
                setLoading(false);
            }
        };
        fetchData();
    }, [
        dispatch,
        school_id,
        unit_id,
        uid,
        value
    ]);
    const handleFilter = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((val)=>setValue(val), []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xl: 12,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_pages_ms_setting_pembayaran_TabelHeaderDetail__WEBPACK_IMPORTED_MODULE_8__["default"], {
                    value: value,
                    handleFilter: handleFilter
                }),
                loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    style: {
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        height: "400px"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CircularProgress, {
                        color: "secondary"
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_3__.DataGrid, {
                    autoHeight: true,
                    rowHeight: 50,
                    rows: store.data,
                    columns: columns,
                    disableRowSelectionOnClick: true,
                    pageSizeOptions: [
                        20,
                        40,
                        60,
                        100
                    ],
                    paginationModel: paginationModel,
                    onPaginationModelChange: setPaginationModel,
                    sx: {
                        "& .MuiDataGrid-cell": {
                            fontSize: "0.75rem"
                        },
                        "& .MuiDataGrid-columnHeaderTitle": {
                            fontSize: "0.75rem"
                        }
                    }
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TabelPaymentMonth);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;