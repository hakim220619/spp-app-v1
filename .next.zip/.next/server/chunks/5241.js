"use strict";
exports.id = 5241;
exports.ids = [5241];
exports.modules = {

/***/ 5241:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "On": () => (/* binding */ deleteAffiliate),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "mR": () => (/* binding */ fetchDataAffiliate)
/* harmony export */ });
/* unused harmony export appAffiliateSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7740);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__]);
src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// ** Fetch Users
const fetchDataAffiliate = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("appAffiliate/fetchDataAffiliate", async (params)=>{
    const storedToken = window.localStorage.getItem("token");
    const customConfig = {
        params,
        headers: {
            Accept: "application/json",
            Authorization: "Bearer " + storedToken
        }
    };
    const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get("/list-affiliate", customConfig);
    return response.data;
});
const deleteAffiliate = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("appAffiliate/deleteAffiliate", async (uid, { getState , dispatch  })=>{
    console.log(getState().jurusan);
    const storedToken = window.localStorage.getItem("token");
    const dataAll = {
        data: uid
    };
    const customConfig = {
        headers: {
            Accept: "application/json",
            Authorization: "Bearer " + storedToken
        }
    };
    const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post("/delete-affiliate", dataAll, customConfig);
    const { q  } = getState().Jurusan;
    // Memanggil fetchDataAffiliate untuk memperbarui data setelah penghapusan
    dispatch(fetchDataAffiliate({
        q
    }));
    return response.data;
});
const appAffiliateSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "appAffiliate",
    initialState: {
        data: [],
        total: 1,
        params: {},
        allData: []
    },
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(fetchDataAffiliate.fulfilled, (state, action)=>{
            state.data = action.payload;
            state.total = action.payload.total;
            state.params = action.payload.params;
            state.allData = action.payload.allData;
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (appAffiliateSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;