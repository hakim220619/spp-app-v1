"use strict";
exports.id = 6865;
exports.ids = [6865];
exports.modules = {

/***/ 6272:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// const urlImage = `http://localhost:3000/`
const urlImage = `https://express-spp-api.sppapp.com/`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (urlImage);


/***/ }),

/***/ 9231:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "h8": () => (/* binding */ deleteUser),
/* harmony export */   "rQ": () => (/* binding */ fetchData)
/* harmony export */ });
/* unused harmony export appUsersSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7740);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__]);
src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// ** Fetch Users
const fetchData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("appUsers/fetchData", async (params)=>{
    const storedToken = window.localStorage.getItem("token");
    const userData = JSON.parse(localStorage.getItem("userData"));
    const customConfig = {
        params,
        headers: {
            Accept: "application/json",
            Authorization: "Bearer " + storedToken
        }
    };
    const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get("/list-admin", customConfig);
    // Cek apakah school_id ada di params, dan filter berdasarkan school_id
    const school_id = userData.school_id;
    let filteredData;
    if (school_id == 1) {
        // Jika school_id = 1, tampilkan semua data
        filteredData = response.data;
    } else {
        // Filter data berdasarkan school_id
        filteredData = response.data.filter((item)=>item.school_id === school_id && item.role !== 180);
    }
    console.log(filteredData);
    return filteredData;
});
const deleteUser = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("appUsers/deleteUser", async (uid, { getState , dispatch  })=>{
    const storedToken = window.localStorage.getItem("token");
    const dataAll = {
        data: uid
    };
    const customConfig = {
        headers: {
            Accept: "application/json",
            Authorization: "Bearer " + storedToken
        }
    };
    const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post("/delete-admin", dataAll, customConfig);
    const { role , status , school , q  } = getState().Admin;
    // Memanggil fetchData untuk memperbarui data setelah penghapusan
    dispatch(fetchData({
        role,
        status,
        school,
        q
    }));
    return response.data;
});
const appUsersSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "appUsers",
    initialState: {
        data: [],
        total: 1,
        params: {},
        allData: []
    },
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(fetchData.fulfilled, (state, action)=>{
            state.data = action.payload;
            state.total = action.payload.total;
            state.params = action.payload.params;
            state.allData = action.payload.allData;
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (appUsersSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;