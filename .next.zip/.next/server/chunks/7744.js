"use strict";
exports.id = 7744;
exports.ids = [7744];
exports.modules = {

/***/ 7744:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "n$": () => (/* binding */ fetchDataSettingPembayaranDetail),
/* harmony export */   "zi": () => (/* binding */ deleteSettingPembayaranDetail)
/* harmony export */ });
/* unused harmony export appSettingPembayaranDetailSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7740);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__]);
src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const fetchDataSettingPembayaranDetail = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("appSettingPembayaranDetail/fetchDataSettingPembayaranDetail", async (params)=>{
    const storedToken = window.localStorage.getItem("token");
    const customConfig = {
        params,
        headers: {
            Accept: "application/json",
            Authorization: "Bearer " + storedToken
        }
    };
    const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get("/list-setting-pembayaran-detail", customConfig);
    return response.data;
});
const deleteSettingPembayaranDetail = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("appSettingPembayaranDetail/deleteSettingPembayaranDetail", async ({ uid , setting_payment_id , user_id  })=>{
    const storedToken = window.localStorage.getItem("token");
    // Updated dataAll to include setting_payment_id and user_id
    const dataAll = {
        data: uid,
        setting_payment_id,
        user_id
    };
    const customConfig = {
        headers: {
            Accept: "application/json",
            Authorization: "Bearer " + storedToken
        }
    };
    const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post("/delete-setting-pembayaran-detail", dataAll, customConfig);
    return response.data;
});
const appSettingPembayaranDetailSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "appSettingPembayaranDetail",
    initialState: {
        data: [],
        total: 1,
        params: {},
        allData: []
    },
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(fetchDataSettingPembayaranDetail.fulfilled, (state, action)=>{
            state.data = action.payload;
            state.total = action.payload.total;
            state.params = action.payload.params;
            state.allData = action.payload.allData;
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (appSettingPembayaranDetailSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;