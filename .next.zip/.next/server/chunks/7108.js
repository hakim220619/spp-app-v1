"use strict";
exports.id = 7108;
exports.ids = [7108];
exports.modules = {

/***/ 7108:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "cN": () => (/* binding */ fetchDataKelas),
/* harmony export */   "gI": () => (/* binding */ deleteKelas)
/* harmony export */ });
/* unused harmony export appUsersSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7740);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__]);
src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// ** Fetch Users
const fetchDataKelas = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("appUsers/fetchDataKelas", async (params)=>{
    const storedToken = window.localStorage.getItem("token");
    const customConfig = {
        params,
        headers: {
            Accept: "application/json",
            Authorization: "Bearer " + storedToken
        }
    };
    const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get("/list-kelas", customConfig);
    console.log(response);
    return response.data;
});
const deleteKelas = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("appUsers/deleteKelas", async (uid, { getState , dispatch  })=>{
    const storedToken = window.localStorage.getItem("token");
    const dataAll = {
        data: uid
    };
    const customConfig = {
        headers: {
            Accept: "application/json",
            Authorization: "Bearer " + storedToken
        }
    };
    const response = await src_configs_axiosConfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post("/delete-kelas", dataAll, customConfig);
    const { school_id , status , q  } = getState().kelas;
    // Memanggil fetchDataKelas untuk memperbarui data setelah penghapusan
    dispatch(fetchDataKelas({
        school_id,
        status,
        q
    }));
    return response.data;
});
const appUsersSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "appUsers",
    initialState: {
        data: [],
        total: 1,
        params: {},
        allData: []
    },
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(fetchDataKelas.fulfilled, (state, action)=>{
            state.data = action.payload;
            state.total = action.payload.total;
            state.params = action.payload.params;
            state.allData = action.payload.allData;
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (appUsersSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;