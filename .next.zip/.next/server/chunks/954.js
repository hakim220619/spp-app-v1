exports.id = 954;
exports.ids = [954];
exports.modules = {

/***/ 7751:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8167);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Card__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8455);
/* harmony import */ var _mui_material_CardContent__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_core_components_mui_chip__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(613);
// ** MUI Imports






// ** Custom Components Imports

const CardStatsCharacter = ({ data  })=>{
    // ** Vars
    const { title , chipText , src , stats , trendNumber , trend ="positive" , chipColor ="primary"  } = data;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Card__WEBPACK_IMPORTED_MODULE_2___default()), {
        sx: {
            overflow: "visible",
            position: "relative"
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CardContent__WEBPACK_IMPORTED_MODULE_5___default()), {
            sx: {
                pb: "0 !important"
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                container: true,
                spacing: 2,
                overflow: "auto",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                        item: true,
                        xs: 12,
                        sm: 6,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                sx: {
                                    mb: 1.5,
                                    fontWeight: 500,
                                    whiteSpace: "nowrap"
                                },
                                children: title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_chip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                skin: "light",
                                size: "small",
                                label: chipText,
                                color: chipColor,
                                sx: {
                                    mb: 5.5,
                                    height: 20,
                                    fontWeight: 500,
                                    fontSize: "0.75rem"
                                }
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                sx: {
                                    display: "flex",
                                    flexWrap: "wrap",
                                    alignItems: "center"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        variant: "h5",
                                        sx: {
                                            mr: 1.5
                                        },
                                        children: stats
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        variant: "caption",
                                        sx: {
                                            color: trend === "negative" ? "error.main" : "success.main"
                                        },
                                        children: trendNumber
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                        item: true,
                        xs: 12,
                        sm: 6,
                        sx: {
                            display: "flex",
                            alignItems: "flex-end",
                            justifyContent: {
                                xs: "center",
                                sm: "flex-end"
                            },
                            marginTop: {
                                xs: "10px",
                                sm: 0
                            },
                            paddingBottom: "20px" // Adjusting the space below the image
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: src,
                                alt: title,
                                style: {
                                    maxWidth: "100%",
                                    height: "auto",
                                    marginTop: "10px"
                                }
                            }),
                            " "
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardStatsCharacter);


/***/ }),

/***/ 7614:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var keen_slider_keen_slider_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6443);
/* harmony import */ var keen_slider_keen_slider_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(keen_slider_keen_slider_min_css__WEBPACK_IMPORTED_MODULE_1__);
// ** MUI imports

// ** KeenSlider CSS

const KeenSliderWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)("div")(({ theme  })=>({
        "& .keen-slider": {
            // Keen Slider handles RTL internally and thus, we need to set the direction to LTR
            direction: "ltr",
            "& .keen-slider__slide": {
                "& img": {
                    height: "auto",
                    maxWidth: "100%"
                }
            },
            "&.thumbnail .keen-slider__slide:not(.active)": {
                opacity: 0.4
            },
            "&.zoom-out": {
                perspective: "1000px",
                "& .zoom-out__slide": {
                    "& .slider-content-wrapper": {
                        width: "100%",
                        height: "100%",
                        position: "absolute",
                        "& img": {
                            width: "100%",
                            height: "100%",
                            objectFit: "cover",
                            position: "absolute",
                            backgroundColor: "transparent"
                        }
                    }
                }
            },
            "& .default-slide": {
                height: 200,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: theme.palette.background.default
            }
        },
        //  ** Fade
        "& .fader": {
            position: "relative",
            overflow: "hidden",
            "& .fader__slide": {
                width: "100%",
                height: "100%",
                position: "absolute",
                top: "0",
                "& img": {
                    width: " 100%",
                    height: " 100%",
                    objectFit: "cover",
                    position: "absolute"
                }
            }
        },
        // ** Navigation Controls
        "& .navigation-wrapper": {
            position: "relative",
            "& .arrow": {
                top: "50%",
                width: "3rem",
                height: "3rem",
                cursor: "pointer",
                position: "absolute",
                transform: "translateY(-50%)",
                color: theme.palette.common.white,
                ...theme.direction === "rtl" ? {
                    transform: "translateY(-50%) rotate(180deg)"
                } : {},
                "&.arrow-disabled": {
                    cursor: "not-allowed",
                    pointerEvents: "none",
                    color: theme.palette.action.disabled
                },
                "&.arrow-left": {
                    left: 0
                },
                "&.arrow-right": {
                    right: 0
                }
            }
        },
        // ** Dots
        "& .swiper-dots": {
            display: "flex",
            justifyContent: "center",
            marginTop: theme.spacing(4),
            "& .MuiBadge-root": {
                "&:not(:last-child)": {
                    marginRight: theme.spacing(4)
                },
                "& .MuiBadge-dot": {
                    width: 10,
                    height: 10,
                    cursor: "pointer",
                    borderRadius: "50%",
                    backgroundColor: theme.palette.action.disabled
                },
                "&.active .MuiBadge-dot": {
                    backgroundColor: theme.palette.primary.main
                }
            }
        }
    }));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (KeenSliderWrapper);


/***/ }),

/***/ 2686:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
// ** MUI imports

const ApexChartWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)("div")(({ theme  })=>({
        "& .apexcharts-canvas": {
            "& line[stroke='transparent']": {
                display: "none"
            },
            "& .apexcharts-tooltip": {
                boxShadow: theme.shadows[3],
                borderColor: theme.palette.divider,
                background: theme.palette.background.paper,
                "& .apexcharts-tooltip-title": {
                    fontWeight: 600,
                    borderColor: theme.palette.divider,
                    background: theme.palette.background.paper
                },
                "&.apexcharts-theme-light": {
                    color: theme.palette.text.primary
                },
                "&.apexcharts-theme-dark": {
                    color: theme.palette.common.white
                },
                "& .apexcharts-tooltip-series-group:first-of-type": {
                    paddingBottom: 0
                },
                "& .bar-chart": {
                    padding: theme.spacing(2, 2.5)
                }
            },
            "& .apexcharts-xaxistooltip": {
                borderColor: theme.palette.divider,
                background: theme.palette.mode === "light" ? theme.palette.grey[50] : theme.palette.customColors.bodyBg,
                "&:after": {
                    borderBottomColor: theme.palette.mode === "light" ? theme.palette.grey[50] : theme.palette.customColors.bodyBg
                },
                "&:before": {
                    borderBottomColor: theme.palette.divider
                }
            },
            "& .apexcharts-yaxistooltip": {
                borderColor: theme.palette.divider,
                background: theme.palette.mode === "light" ? theme.palette.grey[50] : theme.palette.customColors.bodyBg,
                "&:after": {
                    borderLeftColor: theme.palette.mode === "light" ? theme.palette.grey[50] : theme.palette.customColors.bodyBg
                },
                "&:before": {
                    borderLeftColor: theme.palette.divider
                }
            },
            "& .apexcharts-xaxistooltip-text, & .apexcharts-yaxistooltip-text": {
                color: theme.palette.text.primary
            },
            "& .apexcharts-yaxis .apexcharts-yaxis-texts-g .apexcharts-yaxis-label": {
                textAnchor: theme.direction === "rtl" ? "start" : undefined
            },
            "& .apexcharts-text, & .apexcharts-tooltip-text, & .apexcharts-datalabel-label, & .apexcharts-datalabel, & .apexcharts-xaxistooltip-text, & .apexcharts-yaxistooltip-text, & .apexcharts-legend-text": {
                fontFamily: `${theme.typography.fontFamily} !important`
            },
            "& .apexcharts-pie-label": {
                filter: "none",
                fill: theme.palette.common.white
            },
            "& .apexcharts-marker": {
                boxShadow: "none"
            }
        }
    }));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApexChartWrapper);


/***/ }),

/***/ 6443:
/***/ (() => {



/***/ })

};
;