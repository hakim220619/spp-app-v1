"use strict";
exports.id = 8755;
exports.ids = [8755];
exports.modules = {

/***/ 7740:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const axiosConfig = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    // baseURL: `http://localhost:3000/api`
    baseURL: `https://express-spp-api.sppapp.com/api`
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosConfig);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2771:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var src_core_layouts_BlankLayout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7340);
/* harmony import */ var src_views_pages_misc_FooterIllustrations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2288);
/* harmony import */ var src_hooks_useAuth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7218);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_hooks_useAuth__WEBPACK_IMPORTED_MODULE_7__]);
src_hooks_useAuth__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// ** React Imports

// ** MUI Components




// ** Layout Import

// ** Demo Imports


// ** Styled Components
const BoxWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.styled)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()))(({ theme  })=>({
        [theme.breakpoints.down("md")]: {
            width: "90vw"
        }
    }));
const Img = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.styled)("img")(({ theme  })=>({
        [theme.breakpoints.down("lg")]: {
            height: 450,
            marginTop: theme.spacing(10)
        },
        [theme.breakpoints.down("md")]: {
            height: 400
        },
        [theme.breakpoints.up("lg")]: {
            marginTop: theme.spacing(20)
        }
    }));
const Error500 = ()=>{
    const { logout  } = (0,src_hooks_useAuth__WEBPACK_IMPORTED_MODULE_7__/* .useAuth */ .a)();
    const handleBackToHome = ()=>{
        // Clear cookies (userData and token)
        document.cookie = "userData=; Max-Age=0; path=/;";
        document.cookie = "token=; Max-Age=0; path=/;";
        // Clear localStorage (userData and token)
        localStorage.removeItem("userData");
        localStorage.removeItem("token");
        // Redirect to login page
        logout();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
        className: "content-center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                sx: {
                    p: 5,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    textAlign: "center"
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BoxWrapper, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default()), {
                                variant: "h2",
                                sx: {
                                    mb: 1.5
                                },
                                children: "Oops, something went wrong!"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default()), {
                                sx: {
                                    mb: 6,
                                    color: "text.secondary"
                                },
                                children: "There was an error with the internal server. Please contact your site administrator."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
                                onClick: handleBackToHome,
                                variant: "contained",
                                children: "Back to Home"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Img, {
                        height: "500",
                        alt: "error-illustration",
                        src: "/images/pages/404.png"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_views_pages_misc_FooterIllustrations__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
        ]
    });
};
Error500.getLayout = (page)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_layouts_BlankLayout__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        children: page
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Error500);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;