"use strict";
exports.id = 4850;
exports.ids = [4850];
exports.modules = {

/***/ 4850:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_x_data_grid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7738);
/* harmony import */ var _mui_x_data_grid__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var src_core_components_mui_chip__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(613);
/* harmony import */ var src_store_apps_laporan_free__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4244);
/* harmony import */ var src_pages_ms_laporan_TableHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6948);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6201);
/* harmony import */ var src_core_components_icon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3730);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5158);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5464);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([src_store_apps_laporan_free__WEBPACK_IMPORTED_MODULE_6__, src_pages_ms_laporan_TableHeader__WEBPACK_IMPORTED_MODULE_7__, react_hot_toast__WEBPACK_IMPORTED_MODULE_8__, src_core_components_icon__WEBPACK_IMPORTED_MODULE_9__]);
([src_store_apps_laporan_free__WEBPACK_IMPORTED_MODULE_6__, src_pages_ms_laporan_TableHeader__WEBPACK_IMPORTED_MODULE_7__, react_hot_toast__WEBPACK_IMPORTED_MODULE_8__, src_core_components_icon__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const statusObj = {
    Pending: {
        title: "Proses Pembayaran",
        color: "error"
    },
    Verified: {
        title: "Belum Lunas",
        color: "warning"
    },
    Paid: {
        title: "Lunas",
        color: "success"
    }
};
const typeObj = {
    BULANAN: {
        title: "BULANAN",
        color: "info"
    },
    BEBAS: {
        title: "BEBAS",
        color: "warning"
    }
};
const RowOptions = ({ data  })=>{
    const [openPdfPreview, setOpenPdfPreview] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [pdfUrl, setPdfUrl] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const formattedUpdatedAt = new Date(data.created_at).toLocaleString("id-ID", {
        day: "2-digit",
        month: "long",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false
    });
    const createPdf = async ()=>{
        const doc = new (jspdf__WEBPACK_IMPORTED_MODULE_10___default())();
        const logoImageUrl = "/images/logo.png";
        const img = new Image();
        img.src = logoImageUrl;
        img.onload = ()=>{
            // Add the logo
            doc.addImage(img, "PNG", 10, 10, 20, 20);
            // Add school name and address
            doc.setFontSize(14);
            doc.setFont("verdana", "arial", "sans-serif");
            const schoolNameWidth = doc.getTextWidth(data.school_name);
            const xSchoolNamePosition = (doc.internal.pageSize.getWidth() - schoolNameWidth) / 2;
            doc.text(data.school_name, xSchoolNamePosition, 20);
            doc.setFontSize(10);
            doc.setFont("verdana", "arial", "sans-serif");
            const addressWidth = doc.getTextWidth(data.school_address);
            const xAddressPosition = (doc.internal.pageSize.getWidth() - addressWidth) / 2;
            doc.text(data.school_address, xAddressPosition, 26);
            // Draw a horizontal line
            doc.line(10, 32, 200, 32);
            // Student Information
            // Student Information
            // Student Information
            const studentInfoY = 40 // Base Y position for student info
            ;
            const lineSpacing = 4 // Adjust this value to reduce spacing
            ;
            const infoLines = [
                {
                    label: "NIS",
                    value: data.nisn
                },
                {
                    label: "Nama",
                    value: data.full_name
                },
                {
                    label: "Kelas",
                    value: data.class_name
                },
                {
                    label: "Jurusan",
                    value: data.major_name
                }
            ];
            // Set positions for left and right columns
            const leftColumnX = 10 // X position for the left column
            ;
            const rightColumnX = 100 // X position for the right column
            ;
            const labelOffset = 30 // Offset for the label and value
            ;
            infoLines.forEach((info, index)=>{
                const yPosition = studentInfoY + Math.floor(index / 2) * lineSpacing // Increment y for each pair
                ;
                if (index % 2 === 0) {
                    // Even index: Left column for the first two entries
                    doc.text(info.label, leftColumnX, yPosition);
                    doc.text(`: ${info.value}`, leftColumnX + labelOffset, yPosition) // Adjust padding for alignment
                    ;
                } else {
                    // Odd index: Right column for the last two entries
                    doc.text(info.label, rightColumnX, yPosition);
                    doc.text(`: ${info.value}`, rightColumnX + labelOffset, yPosition) // Adjust padding for alignment
                    ;
                }
            });
            // Draw another horizontal line below the student information
            doc.line(10, studentInfoY + 2 * lineSpacing, 200, studentInfoY + 2 * lineSpacing);
            // Payment details header
            doc.text("Dengan rincian pembayaran sebagai berikut:", 10, studentInfoY + infoLines.length * 3);
            const tableBody = [
                [
                    data.id,
                    data.sp_name + " " + data.years,
                    data.status === "Paid" ? "Lunas" : data.status === "Verified" ? "Verifikasi Pembayaran" : "Belum Lunas",
                    formattedUpdatedAt,
                    `Rp. ${(data.amount + data.affiliate).toLocaleString()}`
                ]
            ];
            // Set up the table
            doc.autoTable({
                startY: studentInfoY + infoLines.length * 4,
                margin: {
                    left: 10
                },
                head: [
                    [
                        "ID",
                        "Pembayaran",
                        "Status",
                        "Dibuat",
                        "Total Tagihan"
                    ]
                ],
                body: tableBody,
                theme: "grid",
                headStyles: {
                    fillColor: [
                        30,
                        30,
                        30
                    ],
                    textColor: [
                        255,
                        255,
                        255
                    ],
                    fontSize: 10,
                    font: "verdana",
                    fontStyle: "arial"
                },
                styles: {
                    fontSize: 8,
                    font: "verdana",
                    fontStyle: "arial"
                },
                alternateRowStyles: {
                    fillColor: [
                        230,
                        230,
                        230
                    ] // Change this to your desired secondary color
                },
                columnStyles: {
                    0: {
                        cellWidth: 20
                    },
                    1: {
                        cellWidth: 70
                    },
                    2: {
                        cellWidth: 20
                    },
                    3: {
                        cellWidth: 50
                    },
                    4: {
                        cellWidth: 30
                    } // Total Tagihan column width
                }
            });
            // Create a Blob URL for the PDF
            const pdfOutput = doc.output("blob");
            const blobUrl = URL.createObjectURL(pdfOutput);
            setPdfUrl(blobUrl) // Set the URL for the dialog
            ;
            setOpenPdfPreview(true) // Open the dialog
            ;
        };
        img.onerror = ()=>{
            console.error("Failed to load image:", logoImageUrl);
        };
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                size: "small",
                color: "error",
                onClick: createPdf,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_icon__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    icon: "tabler:file-type-pdf"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Dialog, {
                open: openPdfPreview,
                onClose: ()=>{
                    setOpenPdfPreview(false);
                    setPdfUrl(null) // Clear the URL when closing
                    ;
                },
                maxWidth: "lg",
                fullWidth: true,
                PaperProps: {
                    style: {
                        minHeight: "600px"
                    }
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogTitle, {
                        style: {
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center"
                        },
                        children: [
                            "Preview Payment Receipt",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                onClick: ()=>{
                                    setOpenPdfPreview(false);
                                    setPdfUrl(null) // Clear the URL when closing
                                    ;
                                },
                                color: "error",
                                style: {
                                    position: "absolute",
                                    top: "8px",
                                    right: "8px"
                                },
                                children: "Cancel"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogContent, {
                        children: pdfUrl && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                            src: pdfUrl,
                            width: "100%",
                            height: "800px",
                            title: "PDF Preview",
                            style: {
                                border: "none"
                            }
                        })
                    })
                ]
            })
        ]
    });
};
const columns = [
    {
        field: "no",
        headerName: "No",
        width: 70
    },
    {
        field: "unit_name",
        headerName: "Unit",
        flex: 0.175,
        minWidth: 140
    },
    {
        field: "full_name",
        headerName: "Nama Siswa",
        flex: 0.175,
        minWidth: 140
    },
    {
        field: "sp_name",
        headerName: "Pembayaran",
        flex: 0.175,
        minWidth: 140
    },
    {
        field: "amount",
        headerName: "Jumlah",
        flex: 0.175,
        minWidth: 140,
        renderCell: (params)=>{
            const formattedAmount = new Intl.NumberFormat("id-ID", {
                style: "currency",
                currency: "IDR",
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            }).format(params.value + params.row.affiliate);
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: formattedAmount
            }) // Render the formatted amount
            ;
        }
    },
    {
        field: "type",
        headerName: "Tipe Pembayaran",
        flex: 0.175,
        minWidth: 150,
        renderCell: (params)=>{
            const type = typeObj[params.row.type];
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_chip__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                rounded: true,
                size: "small",
                skin: "light",
                color: type.color,
                label: type.title,
                sx: {
                    "& .MuiChip-label": {
                        textTransform: "capitalize"
                    }
                }
            });
        }
    },
    {
        field: "years",
        headerName: "Tahun",
        flex: 0.175,
        minWidth: 120
    },
    {
        field: "status",
        headerName: "Status",
        flex: 0.175,
        minWidth: 240,
        renderCell: (params)=>{
            const status = statusObj[params.row.status];
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_core_components_mui_chip__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                rounded: true,
                size: "small",
                skin: "light",
                color: status?.color,
                label: status?.title,
                sx: {
                    "& .MuiChip-label": {
                        textTransform: "capitalize"
                    }
                }
            });
        }
    },
    {
        flex: 0,
        minWidth: 200,
        sortable: false,
        field: "actions",
        headerName: "Actions",
        renderCell: ({ row  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RowOptions, {
                uid: row.id,
                data: row
            })
    }
];
const TabelReportPaymentFree = ({ school_id , unit_id , user_id , year , type , setting_payment_uid , refresh  })=>{
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [paginationModel, setPaginationModel] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        page: 0,
        pageSize: 50
    });
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const store = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.ListPaymentReportAdminFree);
    const [openPdfPreview, setOpenPdfPreview] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [pdfUrl, setPdfUrl] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchData = async ()=>{
            setLoading(true);
            try {
                await new Promise((resolve)=>setTimeout(resolve, 1000));
                await dispatch((0,src_store_apps_laporan_free__WEBPACK_IMPORTED_MODULE_6__/* .ListPaymentReportAdminFree */ .km)({
                    school_id,
                    unit_id,
                    user_id,
                    year,
                    type,
                    setting_payment_uid,
                    q: value
                }));
            } catch (error) {
                console.error("Error fetching data:", error);
                react_hot_toast__WEBPACK_IMPORTED_MODULE_8__["default"].error("Failed to fetch data. Please try again.");
            } finally{
                setLoading(false);
            }
        };
        fetchData();
    }, [
        dispatch,
        setting_payment_uid,
        type,
        year,
        school_id,
        unit_id,
        user_id,
        value,
        refresh
    ]);
    const handleFilter = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((val)=>setValue(val), []);
    const createPdf = async ()=>{
        const doc = new (jspdf__WEBPACK_IMPORTED_MODULE_10___default())();
        // Check if store.data has any items
        if (store.data && store.data.length > 0) {
            const pdfData = store.data[0] // Assuming you want to use the first item for the PDF
            ;
            const logoImageUrl = "/images/logo.png";
            const img = new Image();
            img.src = logoImageUrl;
            img.onload = ()=>{
                // Add the logo
                doc.addImage(img, "PNG", 10, 10, 20, 20);
                // Add school name and address
                doc.setFontSize(14);
                doc.setFont("verdana", "arial", "sans-serif");
                const schoolNameWidth = doc.getTextWidth(pdfData.school_name);
                const xSchoolNamePosition = (doc.internal.pageSize.getWidth() - schoolNameWidth) / 2;
                doc.text(pdfData.school_name, xSchoolNamePosition, 20);
                doc.setFontSize(10);
                doc.setFont("verdana", "arial", "sans-serif");
                const addressWidth = doc.getTextWidth(pdfData.school_address);
                const xAddressPosition = (doc.internal.pageSize.getWidth() - addressWidth) / 2;
                doc.text(pdfData.school_address, xAddressPosition, 26);
                // Draw a horizontal line
                doc.line(10, 32, 200, 32);
                // Student Information
                const studentInfoY = 40 // Base Y position for student info
                ;
                const lineSpacing = 4 // Adjust this value to reduce spacing
                ;
                const infoLines = [
                    {
                        label: "NIS",
                        value: pdfData.nisn
                    },
                    {
                        label: "Nama",
                        value: pdfData.full_name
                    },
                    {
                        label: "Kelas",
                        value: pdfData.class_name
                    },
                    {
                        label: "Jurusan",
                        value: pdfData.major_name
                    }
                ];
                // Set positions for left and right columns
                const leftColumnX = 10 // X position for the left column
                ;
                const rightColumnX = 100 // X position for the right column
                ;
                const labelOffset = 30 // Offset for the label and value
                ;
                infoLines.forEach((info, index)=>{
                    const yPosition = studentInfoY + Math.floor(index / 2) * lineSpacing // Increment y for each pair
                    ;
                    if (index % 2 === 0) {
                        // Even index: Left column for the first two entries
                        doc.text(info.label, leftColumnX, yPosition);
                        doc.text(`: ${info.value}`, leftColumnX + labelOffset, yPosition) // Adjust padding for alignment
                        ;
                    } else {
                        // Odd index: Right column for the last two entries
                        doc.text(info.label, rightColumnX, yPosition);
                        doc.text(`: ${info.value}`, rightColumnX + labelOffset, yPosition) // Adjust padding for alignment
                        ;
                    }
                });
                // Draw another horizontal line below the student information
                doc.line(10, studentInfoY + 2 * lineSpacing, 200, studentInfoY + 2 * lineSpacing);
                // Payment details header
                doc.text("Dengan rincian pembayaran sebagai berikut:", 10, studentInfoY + infoLines.length * 3);
                // Initialize tableBody array
                const tableBody = [];
                let totalPayment = 0 // Initialize total payment
                ;
                // Populate tableBody using forEach
                store.data.forEach((item)=>{
                    const formattedUpdatedAt = new Date(item.created_at).toLocaleString("id-ID", {
                        day: "2-digit",
                        month: "long",
                        year: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                        second: "2-digit",
                        hour12: false
                    });
                    tableBody.push([
                        item.id,
                        item.sp_name + " " + item.years,
                        item.status === "Paid" ? "Lunas" : item.status === "Verified" ? "Verifikasi Pembayaran" : "Belum Lunas",
                        formattedUpdatedAt,
                        `Rp. ${(item.amount + item.affiliate).toLocaleString()}`
                    ]);
                    // Add to total payment
                    totalPayment += item.amount + item.affiliate;
                });
                // Add the total row
                tableBody.push([
                    {
                        content: "Total",
                        colSpan: 4,
                        styles: {
                            halign: "right",
                            fontStyle: "bold"
                        }
                    },
                    `Rp. ${totalPayment.toLocaleString()}` // Display the total payment sum
                ]);
                // Set up the table
                doc.autoTable({
                    startY: studentInfoY + infoLines.length * 3 + 4,
                    head: [
                        [
                            "ID",
                            "Pembayaran",
                            "Status",
                            "Dibuat",
                            "Total Tagihan"
                        ]
                    ],
                    margin: {
                        left: 10
                    },
                    body: tableBody,
                    theme: "grid",
                    headStyles: {
                        fillColor: [
                            50,
                            50,
                            50
                        ],
                        textColor: [
                            255,
                            255,
                            255
                        ],
                        fontSize: 10,
                        font: "verdana",
                        fontStyle: "bold"
                    },
                    styles: {
                        fontSize: 8,
                        font: "verdana"
                    },
                    alternateRowStyles: {
                        fillColor: [
                            230,
                            230,
                            230
                        ] // Change this to your desired secondary color
                    },
                    columnStyles: {
                        0: {
                            cellWidth: 20
                        },
                        1: {
                            cellWidth: 50
                        },
                        2: {
                            cellWidth: 30
                        },
                        3: {
                            cellWidth: 60
                        },
                        4: {
                            cellWidth: 30
                        } // Total Tagihan column width
                    }
                });
                // Create a Blob URL for the PDF
                const pdfOutput = doc.output("blob");
                const blobUrl = URL.createObjectURL(pdfOutput);
                setPdfUrl(blobUrl) // Set the URL for the dialog
                ;
                setOpenPdfPreview(true) // Open the dialog
                ;
            };
            img.onerror = ()=>{
                console.error("Failed to load image:", logoImageUrl);
            };
        } else {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_8__["default"].error("Tidak ada data untuk membuat PDF.");
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    xl: 12,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_pages_ms_laporan_TableHeader__WEBPACK_IMPORTED_MODULE_7__["default"], {
                            value: value,
                            handleFilter: handleFilter,
                            cetakPdfAll: createPdf
                        }),
                        loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: {
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                height: "400px"
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CircularProgress, {
                                color: "secondary"
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_3__.DataGrid, {
                            autoHeight: true,
                            rowHeight: 50,
                            rows: store.data,
                            columns: columns,
                            disableRowSelectionOnClick: true,
                            pageSizeOptions: [
                                20,
                                40,
                                60,
                                100
                            ],
                            paginationModel: paginationModel,
                            onPaginationModelChange: setPaginationModel,
                            sx: {
                                "& .MuiDataGrid-cell": {
                                    fontSize: "0.75rem"
                                },
                                "& .MuiDataGrid-columnHeaderTitle": {
                                    fontSize: "0.75rem"
                                }
                            }
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Dialog, {
                open: openPdfPreview,
                onClose: ()=>{
                    setOpenPdfPreview(false);
                    setPdfUrl(null) // Clear the URL when closing
                    ;
                },
                maxWidth: "lg",
                fullWidth: true,
                PaperProps: {
                    style: {
                        minHeight: "600px"
                    }
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogTitle, {
                        style: {
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center"
                        },
                        children: [
                            "Preview Payment Receipt",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                onClick: ()=>{
                                    setOpenPdfPreview(false);
                                    setPdfUrl(null) // Clear the URL when closing
                                    ;
                                },
                                color: "error",
                                style: {
                                    position: "absolute",
                                    top: "8px",
                                    right: "8px"
                                },
                                children: "Cancel"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogContent, {
                        children: pdfUrl && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                            src: pdfUrl,
                            width: "100%",
                            height: "800px",
                            title: "PDF Preview",
                            style: {
                                border: "none"
                            }
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TabelReportPaymentFree);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;