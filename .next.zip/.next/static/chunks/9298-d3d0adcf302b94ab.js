"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[9298],{49298:function(r,e,a){a.r(e),a.d(e,{default:function(){return X}});var t=a(85893),i=a(99226),n=a(66242),o=a(67720),s=a(15861),l=a(44267),d=a(63366),c=a(87462),u=a(67294),b=a(86010),f=a(94780),m=a(70917),h=a(41796),x=a(98216),v=a(2734),p=a(90948),g=a(71657),Z=a(1588),y=a(34867);function j(r){return(0,y.Z)("MuiLinearProgress",r)}(0,Z.Z)("MuiLinearProgress",["root","colorPrimary","colorSecondary","determinate","indeterminate","buffer","query","dashed","dashedColorPrimary","dashedColorSecondary","bar","barColorPrimary","barColorSecondary","bar1Indeterminate","bar1Determinate","bar1Buffer","bar2Indeterminate","bar2Buffer"]);let C=["className","color","value","valueBuffer","variant"],k=r=>r,w,P,$,I,R,S,B=(0,m.F4)(w||(w=k`
  0% {
    left: -35%;
    right: 100%;
  }

  60% {
    left: 100%;
    right: -90%;
  }

  100% {
    left: 100%;
    right: -90%;
  }
`)),L=(0,m.F4)(P||(P=k`
  0% {
    left: -200%;
    right: 100%;
  }

  60% {
    left: 107%;
    right: -8%;
  }

  100% {
    left: 107%;
    right: -8%;
  }
`)),M=(0,m.F4)($||($=k`
  0% {
    opacity: 1;
    background-position: 0 -23px;
  }

  60% {
    opacity: 0;
    background-position: 0 -23px;
  }

  100% {
    opacity: 1;
    background-position: -200px -23px;
  }
`)),q=r=>{let{classes:e,variant:a,color:t}=r,i={root:["root",`color${(0,x.Z)(t)}`,a],dashed:["dashed",`dashedColor${(0,x.Z)(t)}`],bar1:["bar",`barColor${(0,x.Z)(t)}`,("indeterminate"===a||"query"===a)&&"bar1Indeterminate","determinate"===a&&"bar1Determinate","buffer"===a&&"bar1Buffer"],bar2:["bar","buffer"!==a&&`barColor${(0,x.Z)(t)}`,"buffer"===a&&`color${(0,x.Z)(t)}`,("indeterminate"===a||"query"===a)&&"bar2Indeterminate","buffer"===a&&"bar2Buffer"]};return(0,f.Z)(i,j,e)},z=(r,e)=>"inherit"===e?"currentColor":r.vars?r.vars.palette.LinearProgress[`${e}Bg`]:"light"===r.palette.mode?(0,h.$n)(r.palette[e].main,.62):(0,h._j)(r.palette[e].main,.5),N=(0,p.ZP)("span",{name:"MuiLinearProgress",slot:"Root",overridesResolver:(r,e)=>{let{ownerState:a}=r;return[e.root,e[`color${(0,x.Z)(a.color)}`],e[a.variant]]}})(({ownerState:r,theme:e})=>(0,c.Z)({position:"relative",overflow:"hidden",display:"block",height:4,zIndex:0,"@media print":{colorAdjust:"exact"},backgroundColor:z(e,r.color)},"inherit"===r.color&&"buffer"!==r.variant&&{backgroundColor:"none","&::before":{content:'""',position:"absolute",left:0,top:0,right:0,bottom:0,backgroundColor:"currentColor",opacity:.3}},"buffer"===r.variant&&{backgroundColor:"transparent"},"query"===r.variant&&{transform:"rotate(180deg)"})),D=(0,p.ZP)("span",{name:"MuiLinearProgress",slot:"Dashed",overridesResolver:(r,e)=>{let{ownerState:a}=r;return[e.dashed,e[`dashedColor${(0,x.Z)(a.color)}`]]}})(({ownerState:r,theme:e})=>{let a=z(e,r.color);return(0,c.Z)({position:"absolute",marginTop:0,height:"100%",width:"100%"},"inherit"===r.color&&{opacity:.3},{backgroundImage:`radial-gradient(${a} 0%, ${a} 16%, transparent 42%)`,backgroundSize:"10px 10px",backgroundPosition:"0 -23px"})},(0,m.iv)(I||(I=k`
    animation: ${0} 3s infinite linear;
  `),M)),_=(0,p.ZP)("span",{name:"MuiLinearProgress",slot:"Bar1",overridesResolver:(r,e)=>{let{ownerState:a}=r;return[e.bar,e[`barColor${(0,x.Z)(a.color)}`],("indeterminate"===a.variant||"query"===a.variant)&&e.bar1Indeterminate,"determinate"===a.variant&&e.bar1Determinate,"buffer"===a.variant&&e.bar1Buffer]}})(({ownerState:r,theme:e})=>(0,c.Z)({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left",backgroundColor:"inherit"===r.color?"currentColor":(e.vars||e).palette[r.color].main},"determinate"===r.variant&&{transition:"transform .4s linear"},"buffer"===r.variant&&{zIndex:1,transition:"transform .4s linear"}),({ownerState:r})=>("indeterminate"===r.variant||"query"===r.variant)&&(0,m.iv)(R||(R=k`
      width: auto;
      animation: ${0} 2.1s cubic-bezier(0.65, 0.815, 0.735, 0.395) infinite;
    `),B)),F=(0,p.ZP)("span",{name:"MuiLinearProgress",slot:"Bar2",overridesResolver:(r,e)=>{let{ownerState:a}=r;return[e.bar,e[`barColor${(0,x.Z)(a.color)}`],("indeterminate"===a.variant||"query"===a.variant)&&e.bar2Indeterminate,"buffer"===a.variant&&e.bar2Buffer]}})(({ownerState:r,theme:e})=>(0,c.Z)({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left"},"buffer"!==r.variant&&{backgroundColor:"inherit"===r.color?"currentColor":(e.vars||e).palette[r.color].main},"inherit"===r.color&&{opacity:.3},"buffer"===r.variant&&{backgroundColor:z(e,r.color),transition:"transform .4s linear"}),({ownerState:r})=>("indeterminate"===r.variant||"query"===r.variant)&&(0,m.iv)(S||(S=k`
      width: auto;
      animation: ${0} 2.1s cubic-bezier(0.165, 0.84, 0.44, 1) 1.15s infinite;
    `),L)),T=u.forwardRef(function(r,e){let a=(0,g.Z)({props:r,name:"MuiLinearProgress"}),{className:i,color:n="primary",value:o,valueBuffer:s,variant:l="indeterminate"}=a,u=(0,d.Z)(a,C),f=(0,c.Z)({},a,{color:n,variant:l}),m=q(f),h=(0,v.Z)(),x={},p={bar1:{},bar2:{}};if(("determinate"===l||"buffer"===l)&&void 0!==o){x["aria-valuenow"]=Math.round(o),x["aria-valuemin"]=0,x["aria-valuemax"]=100;let r=o-100;"rtl"===h.direction&&(r=-r),p.bar1.transform=`translateX(${r}%)`}if("buffer"===l&&void 0!==s){let r=(s||0)-100;"rtl"===h.direction&&(r=-r),p.bar2.transform=`translateX(${r}%)`}return(0,t.jsxs)(N,(0,c.Z)({className:(0,b.Z)(m.root,i),ownerState:f,role:"progressbar"},x,{ref:e},u,{children:["buffer"===l?(0,t.jsx)(D,{className:m.dashed,ownerState:f}):null,(0,t.jsx)(_,{className:m.bar1,ownerState:f,style:p.bar1}),"determinate"===l?null:(0,t.jsx)(F,{className:m.bar2,ownerState:f,style:p.bar2})]}))});var E=a(60155),O=a(63730);let V=r=>{let{Data:e}=r;return console.log(e),(0,t.jsx)(n.Z,{children:(0,t.jsxs)(l.Z,{children:[(0,t.jsxs)(i.Z,{sx:{mb:6.5,display:"flex",alignItems:"flex-start",justifyContent:"space-between"},children:[(0,t.jsxs)(i.Z,{children:[(0,t.jsx)(s.Z,{variant:"body2",children:"Total Visits"}),(0,t.jsx)(s.Z,{variant:"h6",children:e[0].total+e[1].total})]}),(0,t.jsxs)(i.Z,{sx:{display:"flex",alignItems:"center","& svg":{color:"success.main"}},children:[(0,t.jsxs)(s.Z,{variant:"subtitle2",sx:{color:"success.main"},children:[e[0].total/e[1].total*100,"%"]}),(0,t.jsx)(O.Z,{icon:"mdi:chevron-up"})]})]}),(0,t.jsxs)(i.Z,{sx:{mb:5,display:"flex",alignItems:"center",justifyContent:"space-between"},children:[(0,t.jsxs)(i.Z,{sx:{display:"flex",flexDirection:"column"},children:[(0,t.jsxs)(i.Z,{sx:{mb:2.5,display:"flex",alignItems:"center"},children:[(0,t.jsx)(E.Z,{skin:"light",color:"error",variant:"rounded",sx:{mr:1.5,height:24,width:24,borderRadius:"6px"},children:(0,t.jsx)(O.Z,{icon:"mdi:hours-12",fontSize:"0.875rem"})}),(0,t.jsx)(s.Z,{variant:"body2",children:e[0].waktu})]}),(0,t.jsx)(s.Z,{variant:"h6",children:e[0].total}),(0,t.jsx)(s.Z,{variant:"caption",sx:{color:"text.disabled"}})]}),(0,t.jsx)(o.Z,{flexItem:!0,sx:{m:0},orientation:"vertical",children:(0,t.jsx)(E.Z,{skin:"light",color:"secondary",sx:{height:24,width:24,fontSize:"0.6875rem",color:"text.secondary"},children:"VS"})}),(0,t.jsxs)(i.Z,{sx:{display:"flex",alignItems:"flex-end",flexDirection:"column"},children:[(0,t.jsxs)(i.Z,{sx:{mb:2.5,display:"flex",alignItems:"center"},children:[(0,t.jsx)(s.Z,{sx:{mr:1.5},variant:"body2",children:e[1].waktu}),(0,t.jsx)(E.Z,{skin:"light",variant:"rounded",sx:{height:24,width:24,borderRadius:"6px"},children:(0,t.jsx)(O.Z,{icon:"mdi:hours-12",fontSize:"0.875rem"})})]}),(0,t.jsx)(s.Z,{variant:"h6",children:e[1].total}),(0,t.jsx)(s.Z,{variant:"caption",sx:{color:"text.disabled"}})]})]}),(0,t.jsx)(T,{value:e[0].total,variant:"determinate",sx:{height:10,"&.MuiLinearProgress-colorPrimary":{backgroundColor:"primary.main"},"& .MuiLinearProgress-bar":{borderTopRightRadius:0,borderBottomRightRadius:0,backgroundColor:"warning.main"}}})]})})};var X=V}}]);